frappe.require("assets/india_compliance/js/quick_entry.js");

frappe.setup.on("before_load", function () {
    // if setup wizard is already completed for ERPNext, skip the setup wizard
    if (
        frappe.boot.setup_wizard_completed_apps?.length &&
        frappe.boot.setup_wizard_completed_apps.includes("erpnext")
    ) {
        complete_setup_wizard();
        return;
    }

    const first_slide = frappe.setup.slides[0];
    const _onload = first_slide.onload;

    first_slide.onload = function (slide) {
        _onload.call(this, slide);

        const country_input = frappe.wizard?.slide_dict[0].get_input("country");
        if (country_input) {
            country_input.on("change", (event) => {
                toggle_india_specific_fields(event.target.value);
            });
        }
    };
});

frappe.setup.on("after_load", function () {
    update_erpnext_slides_settings();
});

function complete_setup_wizard() {
    frappe.call({
        method: "india_compliance.setup_wizard.enable_setup_wizard_complete",
        callback: function (r) {
            frappe.ui.toolbar.clear_cache();
        },
    });
}

function toggle_india_specific_fields(country) {
    if (!country) return;

    const india_specific_fields = ["company_gstin", "default_gst_rate", "enable_audit_trail"];

    const hide_field = country && country.toLowerCase() !== "india" ? 1 : 0;

    Object.values(frappe.wizard.slide_dict || {}).forEach((slide) => {
        slide.form?.fields_list?.forEach((fieldobj) => {
            if (india_specific_fields.includes(fieldobj.df.fieldname)) {
                fieldobj.df.hidden = hide_field;
                fieldobj.refresh();
            }
        });
    });
}

function update_erpnext_slides_settings() {
    const slide = erpnext.setup?.slides_settings && erpnext.setup.slides_settings.slice(-1)[0];
    if (!slide) return;

    const _index = can_fetch_gstin_info() ? 0 : 3;

    slide.fields.splice(_index, 0, {
        fieldname: "company_gstin",
        fieldtype: "Data",
        label: __("Company GSTIN"),
    });

    slide.fields.splice(4, 0, {
        fieldname: "default_gst_rate",
        fieldtype: "Select",
        label: __("Default GST Rate"),
        options: [
            "0.0",
            "0.1",
            "0.25",
            "1.0",
            "1.5",
            "3.0",
            "5.0",
            "6.0",
            "7.5",
            "12.0",
            "18.0",
            "28.0",
            "40.0",
        ],
        default: "18.0",
    });

    slide.fields.push({
        fieldname: "enable_audit_trail",
        fieldtype: "Check",
        label: __("Enable Audit Trail"),
        description: __(
            `In accordance with <a
              href='https://egazette.gov.in/WriteReadData/2021/226081.pdf'
              target='_blank'
            > MCA Notification dated 24-03-2021</a>.<br>
            Once enabled, Audit Trail cannot be disabled.`,
        ),
    });

    const _onload = slide.onload;
    slide.onload = function (slide) {
        _onload.call(this, slide);

        toggle_india_specific_fields(frappe.wizard.values.country);

        slide.get_input("company_gstin")?.on("change", async function () {
            autofill_company_info(slide);
        });
    };
}

async function autofill_company_info(slide) {
    const gstin = slide.get_input("company_gstin").val();
    const gstin_field = slide.get_field("company_gstin");

    gstin_field.$input.css("border", "none");

    if (!india_compliance.validate_gstin(gstin)) {
        gstin_field.$input.css("border", "1px solid red");
        return;
    }

    if (!can_fetch_gstin_info()) return;

    const gstin_info = await get_gstin_info(gstin, null, false);

    if (gstin_info.business_name) {
        await slide.get_field("company_name").set_value(gstin_info.business_name);
        slide.get_input("company_name").trigger("input");
    }
}

function can_fetch_gstin_info() {
    return india_compliance.is_api_enabled() && !frappe.boot.gst_settings.sandbox_mode;
}
