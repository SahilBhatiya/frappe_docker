import frappe
from frappe.utils import getdate, flt, today


@frappe.whitelist()
def get_customer_ledger(customer, from_date=None, to_date=None, company=None):
    if not to_date:
        to_date = today()
    if not from_date:
        from_date = frappe.defaults.get_user_default("year_start_date")
        if not from_date:
            t = getdate(to_date)
            fy_year = t.year if t.month >= 4 else t.year - 1
            from_date = f"{fy_year}-04-01"
    if not company:
        company = frappe.defaults.get_user_default("company") or frappe.db.get_single_value("Global Defaults", "default_company")

    from_date = getdate(from_date)
    to_date = getdate(to_date)

    opening = frappe.db.sql("""
        SELECT COALESCE(SUM(debit - credit), 0) as balance
        FROM `tabGL Entry`
        WHERE party_type = 'Customer' AND party = %(customer)s
          AND is_cancelled = 0 AND posting_date < %(from_date)s
          AND (%(company)s IS NULL OR company = %(company)s)
    """, {"customer": customer, "from_date": from_date, "company": company}, as_dict=True)

    opening_balance = flt(opening[0].balance) if opening else 0.0

    entries = frappe.db.sql("""
        SELECT gle.posting_date as date,
            COALESCE(gle.against, gle.remarks, '') as particulars,
            gle.voucher_type as vch_type, gle.voucher_no as vch_no,
            gle.debit, gle.credit, gle.remarks
        FROM `tabGL Entry` gle
        WHERE gle.party_type = 'Customer' AND gle.party = %(customer)s
          AND gle.is_cancelled = 0
          AND gle.posting_date BETWEEN %(from_date)s AND %(to_date)s
          AND (%(company)s IS NULL OR gle.company = %(company)s)
        ORDER BY gle.posting_date, gle.creation
    """, {"customer": customer, "from_date": from_date, "to_date": to_date, "company": company}, as_dict=True)

    total_debit  = sum(flt(e.debit)  for e in entries)
    total_credit = sum(flt(e.credit) for e in entries)
    closing_balance = opening_balance + total_debit - total_credit

    return {
        "opening_balance": opening_balance,
        "entries": entries,
        "total_debit": total_debit,
        "total_credit": total_credit,
        "closing_balance": closing_balance,
        "from_date": str(from_date),
        "to_date": str(to_date),
    }


@frappe.whitelist()
def get_customers_balances(customers, company=None):
    """Return closing GL balance (debit - credit) keyed by customer name."""
    if isinstance(customers, str):
        customers = frappe.parse_json(customers)
    if not customers:
        return {}
    if not company:
        company = frappe.defaults.get_user_default("company") or frappe.db.get_single_value("Global Defaults", "default_company")

    rows = frappe.db.sql("""
        SELECT party, SUM(debit - credit) as balance
        FROM `tabGL Entry`
        WHERE party_type = 'Customer'
          AND party IN %(customers)s
          AND is_cancelled = 0
          AND (%(company)s IS NULL OR company = %(company)s)
        GROUP BY party
    """, {"customers": customers, "company": company}, as_dict=True)

    return {r.party: flt(r.balance) for r in rows}
