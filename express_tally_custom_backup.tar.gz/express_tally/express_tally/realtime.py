# Copyright (c) 2026, Adarsh Motor Stores and contributors
# Realtime push so the POS keeps bills/customers fresh without a manual refresh.

import frappe


def notify_doc_change(doc, method=None):
	"""Broadcast a lightweight 'something changed' event after commit. The POS
	(public/js/pos_realtime.js) listens and refreshes the Recent Orders list /
	the open customer's details. Desk list views already update via Frappe's
	built-in list_update event."""
	try:
		frappe.publish_realtime(
			"exp_rt_update",
			{
				"doctype": doc.doctype,
				"name": doc.name,
				"customer": getattr(doc, "customer", None),
				"status": getattr(doc, "status", None),
			},
			after_commit=True,
		)
	except Exception:
		frappe.log_error(title="exp_rt notify_doc_change failed")
