# Copyright (c) 2026, Adarsh Motor Stores and contributors
#
# WhatsApp payment reminders. A daily scheduled job messages every customer who
# still owes money, once per `reminder_interval_days` (default 5), with ONE
# consolidated message (total outstanding + number of pending bills), repeating
# until the balance reaches zero.
#
# Provider-agnostic: the actual WhatsApp send is a configurable REST call defined
# in Payment Reminder Settings (api_endpoint + request_template JSON + auth_header),
# so any BSP (Interakt / AiSensy / WATI / Meta Cloud ...) works by editing config,
# not code.
#
# SAFETY: nothing sends unless Payment Reminder Settings.enabled is ON. The engine
# only messages a customer who has BOTH a resolvable WhatsApp number AND genuine
# outstanding, so it stays harmless while phone numbers are still being imported and
# payments are being reconciled.

import json
import re

import frappe
from frappe.utils import flt, fmt_money, now_datetime, today

PLACEHOLDERS = (
	"to", "customer", "amount", "count", "template", "sender", "api_key", "intro",
	"invoice_no", "date", "bill_url",
)


def _settings():
	return frappe.get_cached_doc("Payment Reminder Settings")


# ---------------------------------------------------------------- number lookup
def get_whatsapp_number(customer, settings=None):
	"""Resolve a sendable WhatsApp number for a customer, or None.
	Customer.mobile_no first, then a linked Contact's mobile_no/phone."""
	settings = settings or _settings()
	cc = (settings.country_code or "91").strip()

	raw = frappe.db.get_value("Customer", customer, "mobile_no")
	if not raw:
		raw = frappe.db.sql(
			"""select coalesce(nullif(ct.mobile_no,''), ct.phone)
			   from `tabContact` ct
			   join `tabDynamic Link` dl on dl.parent = ct.name
			   where dl.link_doctype = 'Customer' and dl.link_name = %s
			     and (ifnull(ct.mobile_no,'') != '' or ifnull(ct.phone,'') != '')
			   order by ct.is_primary_contact desc
			   limit 1""",
			customer,
		)
		raw = raw[0][0] if raw else None
	return _normalise(raw, cc)


def _normalise(raw, cc):
	if not raw:
		return None
	digits = re.sub(r"\D", "", str(raw))
	if not digits:
		return None
	# strip a leading 0 (local dialing) before applying country code
	if len(digits) == 11 and digits.startswith("0"):
		digits = digits[1:]
	if len(digits) == 10:  # bare 10-digit -> prepend country code
		digits = cc + digits
	# a valid Indian mobile is country code + 10 digits
	if len(digits) == len(cc) + 10 and digits.startswith(cc):
		return digits
	# already includes some country code of plausible length
	if 11 <= len(digits) <= 15:
		return digits
	return None


# ---------------------------------------------------------------- due customers
def _due_customers(settings):
	min_out = flt(settings.min_outstanding) or 0
	rows = frappe.db.sql(
		"""select si.customer, max(si.customer_name) customer_name,
		          round(sum(si.outstanding_amount), 2) due, count(*) bills
		   from `tabSales Invoice` si
		   where si.docstatus = 1 and si.outstanding_amount > 0
		   group by si.customer
		   having due >= %s
		   order by due desc""",
		(min_out,),
		as_dict=True,
	)
	return rows


def _needs_reminder(customer, interval_days):
	"""True if this customer hasn't been reminded within the interval and isn't opted out."""
	row = frappe.db.get_value(
		"Customer",
		customer,
		["custom_disable_payment_reminders", "custom_last_payment_reminder"],
		as_dict=True,
	)
	if not row:
		return True
	if row.custom_disable_payment_reminders:
		return False
	last = row.custom_last_payment_reminder
	if not last:
		return True
	return frappe.utils.date_diff(today(), last) >= int(interval_days or 5)


# ---------------------------------------------------------------- sending
def _render(template_str, ctx):
	"""Replace {{key}} tokens with JSON-safe values."""
	out = template_str or ""
	for key in PLACEHOLDERS:
		val = ctx.get(key, "")
		safe = json.dumps(str(val))[1:-1]  # escape, drop surrounding quotes
		out = out.replace("{{%s}}" % key, safe).replace("{{ %s }}" % key, safe)
	return out


def send_whatsapp(number, ctx, settings, template_name=None, request_template=None, endpoint=None):
	"""POST a template message to the configured gateway. Returns (ok, response_text).

	template_name / request_template / endpoint let other features (e.g.
	invoice-on-submit) reuse this transport with their own template, body shape and
	target URL; all default to the payment-reminder ones on the settings. (WAHA, for
	example, uses /api/sendText for text and /api/sendFile for the bill PDF.)"""
	import requests

	endpoint = endpoint or settings.api_endpoint
	if not endpoint:
		return False, "No API endpoint configured"

	ctx = dict(ctx)
	ctx["to"] = number
	ctx["template"] = template_name or settings.template_name or ""
	ctx["sender"] = settings.sender_number or ""
	ctx["api_key"] = settings.get_password("api_key") if settings.api_key else ""
	ctx["intro"] = settings.message_intro or ""

	headers = {"Content-Type": "application/json"}
	if settings.auth_header:
		for line in (settings.auth_header or "").splitlines():
			if ":" in line:
				k, v = line.split(":", 1)
				headers[k.strip()] = _render(v.strip(), ctx).strip()

	body_str = _render(request_template or settings.request_template or "{}", ctx)
	try:
		payload = json.loads(body_str)
	except Exception:
		return False, "Request template is not valid JSON after substitution: %s" % body_str[:300]

	try:
		method = (settings.http_method or "POST").upper()
		resp = requests.request(
			method, endpoint, headers=headers, json=payload, timeout=30
		)
		ok = 200 <= resp.status_code < 300
		return ok, "HTTP %s: %s" % (resp.status_code, resp.text[:500])
	except Exception as e:
		return False, "Request error: %s" % e


def _log(customer, customer_name, mobile, amount, bills, status, response):
	try:
		frappe.get_doc(
			{
				"doctype": "Payment Reminder Log",
				"customer": customer,
				"customer_name": customer_name,
				"mobile": mobile or "",
				"outstanding_amount": amount,
				"bills": bills,
				"status": status,
				"sent_on": now_datetime(),
				"response": (response or "")[:1000],
			}
		).insert(ignore_permissions=True)
	except Exception:
		frappe.log_error(frappe.get_traceback(), "Payment Reminder Log insert")


def _send_to_customer(row, settings):
	"""Resolve number, send, stamp + log. Returns status string."""
	amount = flt(row.due)
	number = get_whatsapp_number(row.customer, settings)
	if not number:
		_log(row.customer, row.customer_name, None, amount, row.bills, "Skipped", "No WhatsApp number")
		return "Skipped"

	ctx = {
		"customer": row.customer_name or row.customer,
		"amount": fmt_money(amount, currency="INR"),
		"count": row.bills,
	}
	ok, response = send_whatsapp(number, ctx, settings)
	if ok:
		frappe.db.set_value(
			"Customer",
			row.customer,
			{
				"custom_last_payment_reminder": today(),
				"custom_payment_reminder_count": (
					flt(frappe.db.get_value("Customer", row.customer, "custom_payment_reminder_count"))
					+ 1
				),
			},
			update_modified=False,
		)
		_log(row.customer, row.customer_name, number, amount, row.bills, "Sent", response)
		return "Sent"
	_log(row.customer, row.customer_name, number, amount, row.bills, "Failed", response)
	return "Failed"


# ---------------------------------------------------------------- scheduled job
def run_payment_reminders(manual=False):
	"""Daily scheduler entry point. No-op unless enabled and within the send window."""
	settings = _settings()
	if not settings.enabled:
		return {"status": "disabled"}

	if not manual and now_datetime().hour < int(settings.send_hour or 0):
		return {"status": "before send window"}

	interval = int(settings.reminder_interval_days or 5)
	cap = int(settings.max_per_run or 0)
	delay = flt(settings.get("send_delay_seconds"))
	counts = {"Sent": 0, "Failed": 0, "Skipped": 0}

	for row in _due_customers(settings):
		if not _needs_reminder(row.customer, interval):
			continue
		status = _send_to_customer(row, settings)
		counts[status] = counts.get(status, 0) + 1
		if status == "Sent":
			frappe.db.commit()
			# throttle between real sends so a bulk run looks human (protects an
			# unofficial-gateway number from velocity-based bans)
			if delay > 0:
				import time

				time.sleep(delay)
		if cap and counts["Sent"] >= cap:
			break

	frappe.db.commit()
	return {"status": "done", **counts}


# ---------------------------------------------------------------- desk helpers
@frappe.whitelist()
def preview_due_reminders():
	"""List customers who would be messaged today (no send)."""
	settings = _settings()
	interval = int(settings.reminder_interval_days or 5)
	out = []
	for row in _due_customers(settings):
		if not _needs_reminder(row.customer, interval):
			continue
		number = get_whatsapp_number(row.customer, settings)
		out.append(
			{
				"customer": row.customer,
				"customer_name": row.customer_name,
				"outstanding": flt(row.due),
				"bills": row.bills,
				"number": number or "(no number)",
				"reachable": bool(number),
			}
		)
	return {"count": len(out), "reachable": sum(1 for r in out if r["reachable"]), "rows": out[:500]}


@frappe.whitelist()
def send_test_reminder():
	"""Send one test message to Payment Reminder Settings.test_mobile."""
	settings = _settings()
	number = _normalise(settings.test_mobile, (settings.country_code or "91").strip())
	if not number:
		return {"ok": False, "message": "Set a valid Test Mobile in Payment Reminder Settings first."}
	ctx = {"customer": "Test Customer", "amount": fmt_money(1234, currency="INR"), "count": 2}
	ok, response = send_whatsapp(number, ctx, settings)
	return {"ok": ok, "message": response, "number": number}


@frappe.whitelist()
def send_reminder_now(customer):
	"""Manually send a reminder to one customer (ignores the 5-day gate, respects enabled)."""
	settings = _settings()
	if not settings.enabled:
		return {"ok": False, "message": "Payment reminders are disabled."}
	rows = [r for r in _due_customers(settings) if r.customer == customer]
	if not rows:
		return {"ok": False, "message": "Customer has no outstanding above the minimum."}
	status = _send_to_customer(rows[0], settings)
	frappe.db.commit()
	return {"ok": status == "Sent", "message": status}
