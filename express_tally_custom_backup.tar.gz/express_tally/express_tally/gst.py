# Copyright (c) 2026, Adarsh Motor Stores and contributors
# Durable, server-side GST guarantees for every bill (POS / desk / API):
#   1. GST-INCLUSIVE pricing  - the entered price already contains the GST, which is
#      extracted out (grand_total == entered price).
#   2. Correct intra/inter-state tax - CGST+SGST when the place of supply is the home
#      state (Gujarat, 24); IGST when it is any other state. The POS Profile hardcodes
#      the in-state template, so without this an out-of-state B2B sale would wrongly
#      carry CGST/SGST (which india_compliance then rejects). This switches the tax
#      template server-side so it is right regardless of how the bill was raised.
# Both run in before_validate, ahead of the controller's calculate_taxes_and_totals.

import frappe

HOME_STATE_CODE = "24"  # Gujarat - Adarsh's GSTIN starts with 24
IN_STATE_TEMPLATE = "Output GST In-state - AMS"
OUT_STATE_TEMPLATE = "Output GST Out-state - AMS"


def enforce_gst_price_mode(doc, method=None):
	"""before_validate: keep tax inclusive + intra/inter-state correct."""
	_enforce_interstate_template(doc)
	_enforce_inclusive(doc)


def _enforce_inclusive(doc):
	taxes = getattr(doc, "taxes", None)
	if not taxes:
		return

	mode = getattr(doc, "gst_price_mode", None)
	if not mode:
		mode = "With GST"
		# keep the field in sync so the desk form / reports reflect the applied mode
		if hasattr(doc, "gst_price_mode"):
			doc.gst_price_mode = mode

	inclusive = 1 if mode == "With GST" else 0
	for row in taxes:
		if int(row.included_in_print_rate or 0) != inclusive:
			row.included_in_print_rate = inclusive


def _state_code(value):
	"""'24-Gujarat' -> '24'; '24AADFA...' -> '24'; '' -> None."""
	if not value:
		return None
	value = str(value).strip()
	if "-" in value[:3]:
		return value.split("-")[0].strip()
	return value[:2]


def _has_tax_type(taxes, kind):
	"""kind in {'cgst','sgst','igst'} - by gst_tax_type or account name."""
	for t in taxes:
		if (getattr(t, "gst_tax_type", "") or "").lower() == kind:
			return True
		if kind in (t.account_head or "").lower():
			return True
	return False


def _enforce_interstate_template(doc):
	"""Swap the GST template only when the current one disagrees with the place of
	supply, so intra-state bills (the common case) are never disturbed."""
	taxes = getattr(doc, "taxes", None)
	if not taxes:
		return

	company_state = _state_code(doc.get("company_gstin")) or HOME_STATE_CODE
	# place_of_supply is set by india_compliance's before_validate (runs before us);
	# fall back to the recipient GSTIN's state.
	pos_state = _state_code(doc.get("place_of_supply")) or _state_code(doc.get("billing_address_gstin"))
	if not pos_state:
		return  # B2C with no place of supply yet -> leave as-is (intra-state default)

	interstate = pos_state != company_state
	has_cgst = _has_tax_type(taxes, "cgst")
	has_igst = _has_tax_type(taxes, "igst")

	target = None
	if interstate and has_cgst and not has_igst:
		target = OUT_STATE_TEMPLATE
	elif not interstate and has_igst and not has_cgst:
		target = IN_STATE_TEMPLATE
	if not target or not frappe.db.exists("Sales Taxes and Charges Template", target):
		return

	try:
		from erpnext.controllers.accounts_controller import get_taxes_and_charges
		rows = get_taxes_and_charges("Sales Taxes and Charges Template", target)
	except Exception:
		frappe.log_error(frappe.get_traceback(), "express_tally interstate template")
		return

	doc.taxes_and_charges = target
	doc.set("taxes", [])
	for r in rows:
		doc.append("taxes", r)
