// Express Tally - POS "Total" field in Item Details (v1)
//  Adds a "Total" input under Rate in the Item Details panel. Type the line total
//  and the Rate is set to Total / Qty. Unlike the native pos_total_amount field
//  (which recalculated on every render and froze the page), this input ONLY
//  recalculates on a real user edit (the native 'change' event). Setting its value
//  programmatically (on render / qty change) never fires 'change', so clicking an
//  item stays cheap and never loops.
(function () {
	"use strict";
	if (window.__expTotalField_v1) return;
	window.__expTotalField_v1 = true;

	function currentItem() {
		var d = window.cur_pos && cur_pos.item_details;
		return d && d.current_item && d.current_item.name ? d.current_item : null;
	}
	function rowFor(name) {
		var frm = window.cur_pos && cur_pos.frm;
		if (!frm) return null;
		return (frm.doc.items || []).find(function (r) { return r.name === name; });
	}
	function amountOf(row) {
		return flt(row.amount || flt(row.qty) * flt(row.rate), 2);
	}

	function inject() {
		var form = document.querySelector(".item-details-container .form-container");
		if (!form) return;
		var item = currentItem();
		if (!item) return;
		var row = rowFor(item.name);
		if (!row) return;

		var rateCtrl = form.querySelector(".rate-control");
		if (!rateCtrl) return;

		var existing = form.querySelector(".exp-total-control");
		if (existing) {
			// keep the displayed total in sync (qty/rate may have changed) unless
			// the cashier is currently typing in it
			var inp0 = existing.querySelector(".exp-total-input");
			if (inp0 && document.activeElement !== inp0) inp0.value = amountOf(row);
			return;
		}

		var wrap = document.createElement("div");
		wrap.className = "exp-total-control frappe-control";
		wrap.setAttribute("data-fieldname", "exp_total");
		wrap.innerHTML =
			'<div class="form-group">' +
			'<div class="clearfix"><label class="control-label" style="padding-right:0">' +
			__("Total") +
			"</label></div>" +
			'<div class="control-input-wrapper"><div class="control-input">' +
			'<input type="text" inputmode="decimal" autocomplete="off" ' +
			'class="input-with-feedback form-control bold exp-total-input"></div></div>' +
			"</div>";
		rateCtrl.parentNode.insertBefore(wrap, rateCtrl.nextSibling);

		var inp = wrap.querySelector(".exp-total-input");
		inp.value = amountOf(row); // programmatic set -> does NOT fire 'change'

		function commit() {
			var it = currentItem();
			if (!it) return;
			var r = rowFor(it.name);
			if (!r) return;
			var total = flt(inp.value);
			var qty = flt(r.qty);
			if (qty <= 0) return;
			var newRate = total / qty;
			if (Math.abs(flt(r.rate) - newRate) < 0.000001) return; // nothing changed
			frappe.model.set_value("Sales Invoice Item", it.name, "rate", newRate);
		}

		// only a real user edit commits (change fires on blur / Enter)
		inp.addEventListener("change", commit);
		inp.addEventListener("focus", function () {
			var self = this;
			setTimeout(function () { try { self.select(); } catch (e) {} }, 0);
		});
		// don't let key/clicks bubble to the cart-row selection / shortcuts
		["click", "mousedown", "dblclick", "keyup", "pointerdown"].forEach(function (ev) {
			inp.addEventListener(ev, function (e) { e.stopPropagation(); });
		});
		inp.addEventListener("keydown", function (e) {
			e.stopPropagation();
			if (e.key === "Enter") inp.blur();
		});
	}

	function wire() {
		window.expPOS.observe(".item-details-container", inject);
	}
	if (window.expPOS) {
		window.expPOS.onPOS(wire);
	} else {
		var w = 0;
		var t = setInterval(function () {
			if (window.expPOS) { clearInterval(t); window.expPOS.onPOS(wire); }
			else if (++w > 100) clearInterval(t);
		}, 100);
	}
})();
