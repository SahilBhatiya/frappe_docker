// Express Tally - POS cart row remove button (v2 - observer-driven)
//  Adds a small "x" button to each cart line, shown on hover, to remove that
//  item from the bill in one click (reuses the POS controller's own removal
//  logic so totals/GST refresh correctly).
//
//  v2: the 600ms poll is gone; decorate() now runs only when the cart actually
//  re-renders, via the shared rAF-debounced observer (expPOS). Injection is
//  idempotent, so this just stops churning the DOM on a clock.
(function () {
	"use strict";
	if (window.__expCartRemove_v2) return;
	window.__expCartRemove_v2 = true;

	var STYLE =
		".cart-item-wrapper{position:relative;}" +
		".exp-remove-btn{position:absolute;top:50%;right:6px;transform:translateY(-50%);" +
		"z-index:6;width:22px;height:22px;line-height:20px;text-align:center;padding:0;" +
		"border-radius:50%;border:1px solid var(--border-color,#d1d8dd);background:#fff;" +
		"color:#e24c4c;font-size:15px;font-weight:600;cursor:pointer;display:none;}" +
		".cart-item-wrapper:hover .exp-remove-btn{display:block;}" +
		".exp-remove-btn:hover{background:#e24c4c;color:#fff;border-color:#e24c4c;}";

	function injectStyle() {
		if (document.getElementById("exp-remove-style")) return;
		var s = document.createElement("style");
		s.id = "exp-remove-style";
		s.textContent = STYLE;
		document.head.appendChild(s);
	}

	function removeRow(rowName) {
		if (!window.cur_pos) return;
		var frm = cur_pos.frm;
		var row = (frm.doc.items || []).find(function (r) {
			return r.name === rowName;
		});
		if (!row) return;
		frappe.model
			.set_value(row.doctype, row.name, "qty", 0)
			.then(function () {
				frappe.model.clear_doc(row.doctype, row.name);
				cur_pos.update_cart_html(row, true);
				if (cur_pos.item_details) cur_pos.item_details.toggle_item_details_section(null);
			})
			.catch(function (e) {
				console.error("[express_tally] cart remove failed", e);
			});
	}

	function decorate() {
		if (!window.cur_pos) return;
		var rows = document.querySelectorAll(".cart-item-wrapper");
		Array.prototype.forEach.call(rows, function (row) {
			if (row.querySelector(".exp-remove-btn")) return;
			var raw = row.getAttribute("data-row-name");
			if (!raw) return;
			var name = unescape(raw); // data-row-name is escape()'d in the cart markup
			var btn = document.createElement("button");
			btn.className = "exp-remove-btn";
			btn.type = "button";
			btn.title = __("Remove item");
			btn.innerHTML = "&times;";
			btn.addEventListener("click", function (ev) {
				ev.stopPropagation();
				ev.preventDefault();
				removeRow(name);
			});
			row.appendChild(btn);
		});
	}

	function wire() {
		injectStyle();
		window.expPOS.observe(".cart-items-section", decorate);
		decorate();
	}

	if (window.expPOS) {
		window.expPOS.onPOS(wire);
	} else {
		var w = 0;
		var t = setInterval(function () {
			if (window.expPOS) { clearInterval(t); window.expPOS.onPOS(wire); }
			else if (++w > 100) clearInterval(t);
		}, 100);
	}
})();
