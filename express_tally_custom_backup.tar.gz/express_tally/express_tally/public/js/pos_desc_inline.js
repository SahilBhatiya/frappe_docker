// Express Tally - POS inline description (v2 - observer-driven, no jerk)
//  Puts an editable text box on each cart line (under the item name) so the
//  cashier can type the tyre number / note directly in the cart. Saves to the
//  Sales Invoice Item "description". No need to open the item-details panel.
//
//  v2: the 600ms rebuild poll (which destroyed/recreated the input every tick and
//  jerked the box while typing) is gone. decorate() now runs only when the cart
//  actually re-renders, via the shared rAF-debounced observer (expPOS). The
//  focused input's value + caret are preserved across a cart re-render so typing
//  is never interrupted.
(function () {
	"use strict";
	if (window.__expDescInline_v2) return;
	window.__expDescInline_v2 = true;

	var INPUT_CSS =
		"width:96%;margin-top:3px;font-size:12px;line-height:1.3;padding:2px 6px;" +
		"border:1px solid var(--border-color,#d1d8dd);border-radius:6px;color:#444;" +
		"background:#fff;outline:none;";

	function stripHtml(s) {
		if (!s) return "";
		if (s.indexOf("<") === -1) return s;
		var d = document.createElement("div");
		d.innerHTML = s;
		return d.textContent || d.innerText || "";
	}

	// Snapshot the row + caret of any focused inline-desc input, so we can restore
	// it if a cart re-render replaces the row's DOM mid-type.
	function captureFocus() {
		var el = document.activeElement;
		if (!el || !el.classList || !el.classList.contains("exp-desc-input")) return null;
		var row = el.closest(".cart-item-wrapper");
		if (!row) return null;
		return {
			rowName: unescape(row.getAttribute("data-row-name") || ""),
			value: el.value,
			start: el.selectionStart,
			end: el.selectionEnd,
		};
	}

	function restoreFocus(snap) {
		if (!snap || !snap.rowName) return;
		var rows = document.querySelectorAll(".cart-item-wrapper");
		for (var i = 0; i < rows.length; i++) {
			if (unescape(rows[i].getAttribute("data-row-name") || "") !== snap.rowName) continue;
			var inp = rows[i].querySelector(".exp-desc-input");
			if (!inp) return;
			if (document.activeElement === inp) return; // never lost focus
			inp.value = snap.value;
			try {
				inp.focus();
				inp.setSelectionRange(snap.start, snap.end);
			} catch (e) {}
			return;
		}
	}

	function decorate() {
		if (!window.cur_pos || !cur_pos.frm) return;
		var rows = document.querySelectorAll(".cart-item-wrapper");
		Array.prototype.forEach.call(rows, function (row) {
			var holder = row.querySelector(".item-name-desc");
			if (!holder) return;
			// don't rebuild while an input already exists for this row
			if (holder.querySelector(".exp-desc-input")) return;

			var rowName = unescape(row.getAttribute("data-row-name") || "");
			if (!rowName) return;
			var it = (cur_pos.frm.doc.items || []).find(function (r) {
				return r.name === rowName;
			});
			if (!it) return;

			// hide the static description line once (we replace it with an input)
			var staticDesc = holder.querySelector(".item-desc");
			if (staticDesc && staticDesc.style.display !== "none") staticDesc.style.display = "none";

			var inp = document.createElement("input");
			inp.type = "text";
			inp.className = "exp-desc-input";
			inp.placeholder = __("Tyre number / note");
			inp.value = stripHtml(it.description || "");
			inp.setAttribute("style", INPUT_CSS);

			// keep clicks/taps/keys from selecting the row or hitting the numpad
			["click", "mousedown", "dblclick", "keydown", "keyup", "touchstart", "pointerdown"].forEach(
				function (ev) {
					inp.addEventListener(ev, function (e) {
						e.stopPropagation();
					});
				}
			);

			function save() {
				try {
					frappe.model.set_value("Sales Invoice Item", rowName, "description", inp.value);
				} catch (e) {}
			}
			inp.addEventListener("change", save);
			inp.addEventListener("blur", save);
			inp.addEventListener("keydown", function (e) {
				if (e.key === "Enter") inp.blur();
			});

			holder.appendChild(inp);
		});
	}

	function run() {
		var snap = captureFocus(); // remember in-progress typing before re-decorating
		try { decorate(); } catch (e) {}
		restoreFocus(snap); // re-attach to a rebuilt row so the caret never jumps
	}

	function wire() {
		window.expPOS.observe(".cart-items-section", run);
		run();
	}

	if (window.expPOS) {
		window.expPOS.onPOS(wire);
	} else {
		var w = 0;
		var t = setInterval(function () {
			if (window.expPOS) { clearInterval(t); window.expPOS.onPOS(wire); }
			else if (++w > 100) clearInterval(t);
		}, 100);
	}
})();
