// Express Tally - POS Item Details patches (v9)
//  A) description -> Small Text (Text Editor froze mobile)
//  B) description empty by default (don't auto-fill with the item name)
//  C) GST always charged (the old "Charge GST" toggle is removed)
//  NOTE: the native "pos_total_amount" field is REMOVED again here. Re-enabling it
//  (v7) froze the page on every item click: rendering it fires set_value->onchange
//  ->rate recalc->re-render->recalc... on this india_compliance build. The "Total"
//  field is instead provided by pos_total_field.js, which only recalculates when
//  the cashier actually edits it (never on render), so clicking an item is cheap.
(function () {
	"use strict";
	if (window.__expressTallyPosFix_v9) return;
	window.__expressTallyPosFix_v9 = true;

	function stripHtml(s) {
		if (!s) return "";
		if (s.indexOf("<") === -1) return s;
		var d = document.createElement("div");
		d.innerHTML = s;
		return d.textContent || d.innerText || "";
	}

	function patchItemDetails() {
		if (!(window.erpnext && erpnext.PointOfSale && erpnext.PointOfSale.ItemDetails)) return false;
		var proto = erpnext.PointOfSale.ItemDetails.prototype;
		if (proto.__expV9) return true;

		// (A) description Text Editor -> Small Text (Text Editor froze mobile)
		var origRenderForm = proto.render_form;
		proto.render_form = function (item) {
			var fields = this.item_meta && this.item_meta.fields;
			var idx = -1, origDf = null;
			if (fields && fields.findIndex) {
				idx = fields.findIndex(function (df) { return df.fieldname === "description"; });
				if (idx > -1 && fields[idx].fieldtype === "Text Editor") {
					origDf = fields[idx];
					fields[idx] = Object.assign({}, origDf, { fieldtype: "Small Text" });
				}
			}
			try { return origRenderForm.call(this, item); }
			finally { if (origDf && idx > -1) fields[idx] = origDf; }
		};

		// Remove the native total field (it caused the recalc freeze on item click).
		var origGetFields = proto.get_form_fields;
		proto.get_form_fields = function (item) {
			return (origGetFields.call(this, item) || []).filter(function (x) {
				return x !== "pos_total_amount";
			});
		};

		proto.__expV9 = true;
		return true;
	}

	// (B) description empty by default (POS only). ERPNext auto-fills the line
	//     description with the item name (and re-fills it AFTER item_code is set,
	//     from the Item master), so a one-shot clear on item_code is overwritten.
	//     We also clear whenever the description lands as the item-name default —
	//     but never touch a tyre-number / note the cashier typed (that won't equal
	//     the item name).
	function patchDescriptionDefault() {
		if (!(window.frappe && frappe.model && frappe.model.on)) return false;
		if (window.__expDescDefaultBound) return true;

		function maybeClear(doc) {
			if (!window.cur_pos || !doc || !doc.description) return;
			var desc = stripHtml(doc.description).trim();
			if (!desc) return;
			var name = (doc.item_name || "").trim();
			// only blank the AUTO default (= item name); keep cashier-typed notes
			if (name && desc === name) {
				try { frappe.model.set_value(doc.doctype, doc.name, "description", ""); } catch (e) {}
			}
		}
		frappe.model.on("Sales Invoice Item", "item_code", function (fn, value, doc) {
			setTimeout(function () { maybeClear(doc); }, 0);
		});
		frappe.model.on("Sales Invoice Item", "description", function (fn, value, doc) {
			maybeClear(doc);
		});
		window.__expDescDefaultBound = true;
		return true;
	}

	// (C) remove any cached "Charge GST" toggle (GST is always charged now).
	function removeGstToggle() {
		var el = document.querySelector(".exp-gst-toggle");
		if (el) el.remove();
	}

	function applyPatch() {
		if (patchItemDetails()) return;
		var n = 0;
		var t = setInterval(function () {
			if (patchItemDetails() || ++n > 60) clearInterval(t);
		}, 150);
	}

	applyPatch();
	patchDescriptionDefault();

	function wireObserver() {
		window.expPOS.observe(".item-details-container", removeGstToggle);
	}
	if (window.expPOS) {
		window.expPOS.onPOS(wireObserver);
	} else {
		var w = 0;
		var t = setInterval(function () {
			if (window.expPOS) { clearInterval(t); window.expPOS.onPOS(wireObserver); }
			else if (++w > 100) clearInterval(t);
		}, 100);
	}
})();
