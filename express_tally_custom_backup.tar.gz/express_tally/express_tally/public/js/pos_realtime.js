// Express Tally - POS realtime (v1)
//  Keeps the POS fresh without a manual refresh. Subscribes to the server's
//  "exp_rt_update" event (published by express_tally.realtime.notify_doc_change):
//   - a bill (Sales/POS Invoice) changed -> refresh the Recent Orders list, but
//     ONLY while that panel is open (so it never yanks the screen mid-sale).
//   - the customer currently on the bill was edited -> repaint their details.
//  New customers are already searchable live (the customer box queries the server
//  on each keystroke). Desk Customer/Invoice lists update via Frappe's built-in
//  list_update - nothing to do here.
(function () {
	"use strict";
	if (window.__expRealtime_v1) return;
	window.__expRealtime_v1 = true;

	var pending = null;

	function refreshRecentOrders() {
		try {
			var rol = window.cur_pos && cur_pos.recent_order_list;
			if (rol && rol.$component && rol.$component.is(":visible")) {
				rol.refresh_list();
			}
		} catch (e) {}
	}

	function scheduleRecentOrders() {
		if (pending) return; // debounce a burst of events into one refresh
		pending = setTimeout(function () {
			pending = null;
			refreshRecentOrders();
		}, 800);
	}

	function refreshOpenCustomer(name) {
		try {
			var frm = window.cur_pos && cur_pos.frm;
			var cart = window.cur_pos && cur_pos.cart;
			if (!frm || !cart || !name || frm.doc.customer !== name) return;
			if (cart.fetch_customer_details) {
				var r = cart.fetch_customer_details(name);
				var done = function () { cart.update_customer_section && cart.update_customer_section(); };
				if (r && r.then) r.then(done); else done();
			}
		} catch (e) {}
	}

	function handler(data) {
		if (!data || !data.doctype) return;
		if (data.doctype === "Sales Invoice" || data.doctype === "POS Invoice") {
			scheduleRecentOrders();
		} else if (data.doctype === "Customer") {
			refreshOpenCustomer(data.name);
		}
	}

	function wire() {
		if (window.__expRtBound) return;
		if (!(window.frappe && frappe.realtime && frappe.realtime.on)) return;
		frappe.realtime.on("exp_rt_update", handler);
		window.__expRtBound = true;
	}

	if (window.expPOS) {
		window.expPOS.onPOS(wire);
	} else {
		var w = 0;
		var t = setInterval(function () {
			if (window.expPOS) { clearInterval(t); window.expPOS.onPOS(wire); }
			else if (++w > 100) clearInterval(t);
		}, 100);
	}
})();
