// Express Tally - POS claim marking (v2)
//  Shows "Claim" + "Claim No. / Reason" in the Item Details panel (not the cart
//  line). The cashier opens an item, ticks Claim, types the claim no, and edits
//  the Rate lower as usual. Saved to Sales Invoice Item.custom_is_claim /
//  custom_claim_no (these feed the Tyre Claim Register report).
(function () {
	"use strict";
	if (window.__expClaim_v2) return;
	window.__expClaim_v2 = true;

	function patch() {
		if (!(window.erpnext && erpnext.PointOfSale && erpnext.PointOfSale.ItemDetails)) return false;
		var proto = erpnext.PointOfSale.ItemDetails.prototype;
		if (proto.__expClaimV2) return true;
		var origGetFields = proto.get_form_fields;
		proto.get_form_fields = function (item) {
			var fields = (origGetFields.call(this, item) || []).slice();
			if (fields.indexOf("custom_is_claim") === -1) fields.push("custom_is_claim");
			if (fields.indexOf("custom_claim_no") === -1) fields.push("custom_claim_no");
			return fields;
		};
		proto.__expClaimV2 = true;
		return true;
	}

	var n = 0;
	var timer = setInterval(function () {
		if (patch() || ++n > 300) clearInterval(timer);
	}, 300);
})();
