// Express Tally - POS "Car No." selector (v3 - observer-driven)
//  Adds a Car field under the customer in the POS. The cashier can:
//   - pick one of the selected customer's cars (shown as quick chips), or
//   - type / create a new car number (inline-creates a Customer Car master).
//  The chosen car is written to Sales Invoice.custom_car; on submit the server
//  hook (express_tally.car.link_car_to_customer) attaches it to the customer.
//
//  v3:
//   - CAN REMOVE a car: clearing the text box (or clicking the active chip again)
//     takes the car off the bill. (A frappe Link control keeps its stored value
//     when you only delete the text, and inject() used to resurrect it - both
//     fixed: we clear on empty input text, and never re-sync while it's focused.)
//   - CURRENT ODOMETER: an editable "Odometer (km)" box; selecting a car prefills
//     it from the Customer Car, editing it saves the car's latest reading via the
//     whitelisted express_tally.car.set_car_odometer (Sales User has no write perm
//     on Customer Car, so it must go through the server method).
(function () {
	"use strict";
	if (window.__expressTallyCarFix_v3) return;
	window.__expressTallyCarFix_v3 = true;

	var carControl = null;
	var $section = null;
	var lastCustomer = null;
	var lastOdoCar = null;

	function getFrm() {
		return window.cur_pos && window.cur_pos.frm;
	}

	function carInputFocused() {
		return carControl && carControl.$input && document.activeElement === carControl.$input.get(0);
	}

	function setCar(val) {
		var frm = getFrm();
		if (!frm) return;
		val = val || "";
		frm.doc.custom_car = val;
		if (carControl && (carControl.get_value() || "") !== val) {
			carControl.set_value(val);
		}
		renderChips(); // refresh active state
		refreshOdometer(val);
	}

	function renderChips() {
		if (!$section) return;
		var frm = getFrm();
		var customer = frm && frm.doc.customer;
		var $chips = $section.find(".exp-car-chips");
		if (!customer) {
			$chips.html('<span class="text-muted">' + __("Select a customer to see their cars") + "</span>");
			return;
		}
		frappe
			.call({
				method: "express_tally.car.get_customer_cars",
				args: { customer: customer },
			})
			.then(function (res) {
				var rows = (res && res.message) || [];
				var cars = [];
				rows.forEach(function (r) {
					if (r.car && cars.indexOf(r.car) === -1) cars.push(r.car);
				});
				if (!cars.length) {
					$chips.html('<span class="text-muted">' + __("No saved cars - type the number below") + "</span>");
					return;
				}
				var active = (frm && frm.doc.custom_car) || "";
				$chips.empty();
				cars.forEach(function (c) {
					var $b = $(
						'<button type="button" class="btn btn-xs exp-car-chip" style="margin:2px 4px 2px 0;"></button>'
					)
						.text(c)
						.toggleClass("btn-primary", c === active)
						.toggleClass("btn-default", c !== active);
					$b.on("click", function () {
						// clicking the already-active chip de-selects (removes the car)
						var cur = (getFrm() && getFrm().doc.custom_car) || "";
						setCar(c === cur ? "" : c);
					});
					$chips.append($b);
				});
			});
	}

	function buildControl() {
		var $field = $section.find(".exp-car-control");
		carControl = frappe.ui.form.make_control({
			df: {
				fieldtype: "Link",
				options: "Customer Car",
				label: __("Car No."),
				fieldname: "exp_car",
				placeholder: __("Car number"),
				onchange: function () {
					// decide by the visible text, not the (stale) stored Link value,
					// so deleting the text actually clears the car
					var txt = carControl.$input ? (carControl.$input.val() || "").trim() : "";
					setCar(txt ? (carControl.get_value() || txt) : "");
				},
			},
			parent: $field.get(0),
			render_input: true,
		});
		carControl.refresh();

		// empty the text box -> remove the car
		var $inp = carControl.$input;
		if ($inp && $inp.length) {
			$inp.on("change blur", function () {
				if (!($inp.val() || "").trim()) setCar("");
			});
		}
	}

	function refreshOdometer(car) {
		if (!$section) return;
		var $odo = $section.find(".exp-odo-input");
		if (!$odo.length) return;
		lastOdoCar = car || "";
		if (!car) {
			$odo.val("").prop("disabled", true);
			return;
		}
		$odo.prop("disabled", false);
		frappe.db.get_value("Customer Car", car, "current_odometer").then(function (r) {
			var v = r && r.message ? r.message.current_odometer : null;
			if (document.activeElement !== $odo.get(0)) {
				$odo.val(flt(v) ? v : "");
			}
		});
	}

	function saveOdometer() {
		var car = (getFrm() && getFrm().doc.custom_car) || "";
		if (!car) return;
		var $odo = $section.find(".exp-odo-input");
		var val = flt($odo.val());
		frappe
			.call({ method: "express_tally.car.set_car_odometer", args: { car: car, odometer: val } })
			.then(function () {
				frappe.show_alert({ message: __("Odometer saved for {0}", [car]), indicator: "green" });
			});
	}

	function buildOdometer() {
		var $odo = $section.find(".exp-odo-input");
		if (!$odo.length) return;
		$odo.on("change blur", saveOdometer);
		$odo.on("keydown", function (e) {
			e.stopPropagation();
			if (e.key === "Enter") $(this).blur();
		});
		["click", "mousedown", "keyup", "pointerdown"].forEach(function (ev) {
			$odo.on(ev, function (e) { e.stopPropagation(); });
		});
	}

	function inject() {
		if (!window.cur_pos) return;
		var $cs = $(".customer-cart-container .customer-section");
		if (!$cs.length) $cs = $(".customer-section");
		if (!$cs.length) return;

		if (!$section || !document.body.contains($section.get(0))) {
			$(".exp-car-section").remove();
			$section = $(
				'<div class="exp-car-section" style="padding:8px 14px;border-bottom:1px solid var(--border-color,#ebeff2);">' +
					'<div style="font-size:11px;color:var(--text-muted,#8d99a6);margin-bottom:4px;">' +
					__("Car") +
					"</div>" +
					'<div class="exp-car-chips" style="margin-bottom:6px;"></div>' +
					'<div class="exp-car-control"></div>' +
					'<div class="exp-odo-row" style="margin-top:6px;">' +
						'<div style="font-size:11px;color:var(--text-muted,#8d99a6);margin-bottom:4px;">' +
						__("Odometer (km)") +
						"</div>" +
						'<input type="text" inputmode="decimal" autocomplete="off" ' +
						'class="form-control exp-odo-input" placeholder="' + __("Current reading") + '" disabled>' +
					"</div>" +
					"</div>"
			);
			$cs.after($section);
			buildControl();
			buildOdometer();
			lastCustomer = null;
			lastOdoCar = null;
		}

		var frm = getFrm();
		var customer = frm && frm.doc.customer;
		if (customer !== lastCustomer) {
			lastCustomer = customer;
			// new customer selected -> refresh the saved-cars chips
			renderChips();
		}
		// keep control in sync if doc.custom_car changed elsewhere - but NEVER while
		// the cashier is editing the box (that's what used to resurrect a cleared car)
		if (carControl && frm && !carInputFocused() &&
			(frm.doc.custom_car || "") !== (carControl.get_value() || "")) {
			carControl.set_value(frm.doc.custom_car || "");
		}
		// load the odometer when the car changes
		var curCar = (frm && frm.doc.custom_car) || "";
		if (curCar !== lastOdoCar) refreshOdometer(curCar);
	}

	function wire() {
		// Re-build the section if the POS re-rendered it away, and re-sync chips on
		// any customer/cart change - only when the DOM actually mutates.
		window.expPOS.observe(".customer-cart-container", function () {
			try { inject(); } catch (e) {}
		});
		inject();
	}

	if (window.expPOS) {
		window.expPOS.onPOS(wire);
	} else {
		var w = 0;
		var t = setInterval(function () {
			if (window.expPOS) { clearInterval(t); window.expPOS.onPOS(wire); }
			else if (++w > 100) clearInterval(t);
		}, 100);
	}
})();
