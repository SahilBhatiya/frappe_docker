// Express Tally - shared POS observer/scheduler (v1)
//  Replaces the per-feature setInterval polling loops with ONE MutationObserver
//  on the POS app root. Subscribers register a (selector, callback); their
//  callback fires - rAF-debounced - only when the DOM actually changes, so the
//  grid/cart no longer reflow ~10x/second (that was the "jerk").
//
//  API (window.expPOS):
//    observe(selector, cb)  -> cb() runs once now (if root present) and again,
//                              coalesced to one call per animation frame, on any
//                              mutation under .point-of-sale-app. `selector` is a
//                              hint for the reader; cb decides what to do.
//    onPOS(cb)              -> cb(cur_pos) runs once as soon as the POS page +
//                              window.cur_pos exist (and again if the POS is
//                              re-entered after leaving the route). Use for
//                              one-time prototype patches / wiring.
(function () {
	"use strict";
	if (window.expPOS) return;

	var ROOT_SEL = ".point-of-sale-app";
	var subs = [];        // [{ selector, cb }]
	var onPosSubs = [];   // [cb]
	var observer = null;
	var observedRoot = null;
	var rafId = null;
	var lastPosSeen = null;

	function inPOS() {
		try {
			return frappe.get_route && frappe.get_route()[0] === "point-of-sale";
		} catch (e) {
			return false;
		}
	}

	function flush() {
		rafId = null;
		for (var i = 0; i < subs.length; i++) {
			try { subs[i].cb(); } catch (e) { /* keep other subs alive */ }
		}
	}

	function schedule() {
		if (rafId != null) return; // coalesce a burst of mutations into one pass
		rafId = (window.requestAnimationFrame || function (f) { return setTimeout(f, 16); })(flush);
	}

	function ensureObserver() {
		var root = document.querySelector(ROOT_SEL);
		if (!root) { observedRoot = null; return false; }
		if (observer && observedRoot === root) return true;
		if (observer) observer.disconnect();
		observer = new MutationObserver(schedule);
		observer.observe(root, { childList: true, subtree: true });
		observedRoot = root;
		schedule(); // run subs once against the fresh root
		return true;
	}

	function fireOnPos() {
		if (!inPOS() || !window.cur_pos) return;
		if (lastPosSeen === window.cur_pos) return;
		lastPosSeen = window.cur_pos;
		for (var i = 0; i < onPosSubs.length; i++) {
			try { onPosSubs[i](window.cur_pos); } catch (e) {}
		}
	}

	window.expPOS = {
		observe: function (selector, cb) {
			subs.push({ selector: selector, cb: cb });
			if (observedRoot) schedule();
		},
		onPOS: function (cb) {
			onPosSubs.push(cb);
			fireOnPos();
		},
	};

	// One lightweight heartbeat (not a per-feature poll): keep the single observer
	// attached to the current POS root and detect POS (re)entry. 500ms is plenty -
	// it does no DOM writes, just (re)wires the observer when the page mounts.
	setInterval(function () {
		try {
			if (inPOS()) {
				ensureObserver();
				fireOnPos();
			} else {
				lastPosSeen = null; // so re-entering the POS re-fires onPOS subs
			}
		} catch (e) {}
	}, 500);

	// React immediately to route changes too (faster than the heartbeat).
	if (window.frappe && frappe.router && frappe.router.on) {
		frappe.router.on("change", function () {
			setTimeout(function () {
				if (inPOS()) { ensureObserver(); fireOnPos(); }
			}, 0);
		});
	}
})();
