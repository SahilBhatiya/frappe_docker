// Express Tally - POS payment amount input (v1)
//  Since the on-screen numpad is hidden (keyboard-based POS), on a phone there was
//  no way to type the amount: the per-mode amount field exists but core keeps it
//  hidden and only feeds a hardware keyboard through a "cents calculator" handler
//  (so typing produced garbage like 5080.05). This shows the SELECTED mode's real
//  input full-width and focuses it, so the soft keyboard appears and you can type a
//  normal number. The keydown is kept local (stopPropagation) so core's cents
//  handler no longer mangles the value; the control's own change still saves the
//  amount to the model and refreshes the totals.
(function () {
	"use strict";
	if (window.__expPayInput_v1) return;
	window.__expPayInput_v1 = true;

	function showInputFor(modeEl, mode) {
		var pay = window.cur_pos && cur_pos.payment;
		var ctrl = pay && pay[mode + "_control"];
		if (!ctrl) return;

		// core just hid every control + showed every .pay-amount; reveal this one
		var $mode = $(modeEl);
		$mode.find(".mode-of-payment-control").css("display", "block");
		$mode.find(".pay-amount").css("display", "none");

		var $input = ctrl.$input;
		if (!$input || !$input.length) return;

		$input.attr("inputmode", "decimal");
		if (!$input.data("expPayBound")) {
			// keep keystrokes local so core's document "cents" keydown can't fire
			$input.on("keydown", function (ev) {
				ev.stopPropagation();
				if (ev.key === "Enter") $(this).blur();
			});
			$input.on("focus", function () {
				var self = this;
				setTimeout(function () { try { self.select(); } catch (e) {} }, 0);
			});
			$input.data("expPayBound", true);
		}
		// focus synchronously (still inside the tap gesture) so mobile opens the keyboard
		try { $input.get(0).focus(); } catch (e) {}
	}

	// Runs AFTER core's delegated .mode-of-payment handler (core is bound on
	// .payment-modes, this on document -> bubbles later), so border-primary is set.
	$(document).on("click", ".point-of-sale-app .mode-of-payment", function () {
		var mode = this.getAttribute("data-mode");
		if (!mode || mode === "loyalty-amount") return;
		if (!this.classList.contains("border-primary")) return; // only when now selected
		showInputFor(this, mode);
	});
})();
