// Express Tally - POS payment quick-fill (v1)
//  Double-click a payment method (Cash / UPI / ...) to put the FULL amount due
//  into that method and zero the others - so you don't have to type the amount.
(function () {
	"use strict";
	if (window.__expPayFill_v1) return;
	window.__expPayFill_v1 = true;

	$(document).on("dblclick", ".mode-of-payment", function (e) {
		try {
			var pay = window.cur_pos && cur_pos.payment;
			if (!pay || !cur_pos.frm) return;
			var clickedMode = $(this).attr("data-mode");
			if (!clickedMode || clickedMode === "loyalty-amount") return;

			e.preventDefault();
			if (window.getSelection) {
				try { window.getSelection().removeAllRanges(); } catch (err) {}
			}

			var doc = cur_pos.frm.doc;
			var due = flt(doc.rounded_total) || flt(doc.grand_total);

			(doc.payments || []).forEach(function (p) {
				var key = pay.sanitize_mode_of_payment(p.mode_of_payment);
				var ctrl = pay[key + "_control"];
				if (!ctrl) return;
				var target = key === clickedMode ? due : 0;
				if (flt(ctrl.get_value()) !== flt(target)) ctrl.set_value(target);
			});
		} catch (err) {
			console.error("[express_tally] payment quick-fill failed", err);
		}
	});
})();
