// Express Tally - POS bundle auto-add (v2 - observer-driven)
//  When a tyre that has a bundle mapping (Item.custom_bundle_tube / custom_bundle_flap)
//  is added in POS, its tube + flap are auto-added as separate, editable lines (qty 1).
//  The cashier can change qty/price or delete a line. Each tyre expands once per order.
//
//  v2: the 700ms wrap/bookkeeping poll is gone. on_cart_update is wrapped once on
//  POS entry; the per-invoice "expanded" reset is driven by the shared observer
//  (expPOS) - it fires only when the cart actually changes.
(function () {
	"use strict";
	if (window.__expBundle_v2) return;
	window.__expBundle_v2 = true;

	var origUpdate = null; // original cur_pos.on_cart_update (bound)
	var wrappedRef = null; // cur_pos instance currently wrapped
	var expanded = {}; // tyre item_code -> already expanded this order
	var cache = {}; // tyre item_code -> [components] | null
	var lastInvoice = null;

	function getComponents(code) {
		if (code in cache) return Promise.resolve(cache[code]);
		return frappe.db
			.get_value("Item", code, ["custom_bundle_tube", "custom_bundle_flap"])
			.then(function (r) {
				var comp = [];
				var m = r && r.message;
				if (m) {
					if (m.custom_bundle_tube) comp.push(m.custom_bundle_tube);
					if (m.custom_bundle_flap) comp.push(m.custom_bundle_flap);
				}
				cache[code] = comp.length ? comp : null;
				return cache[code];
			});
	}

	function getInfo(code) {
		var frm = window.cur_pos && cur_pos.frm;
		var pl = frm && frm.doc.selling_price_list;
		var info = { rate: 0, uom: "Nos" };
		return frappe.db
			.get_value("Item", code, ["standard_rate", "stock_uom"])
			.then(function (r) {
				if (r && r.message) {
					info.uom = r.message.stock_uom || "Nos";
					info.rate = flt(r.message.standard_rate) || 0;
				}
				return frappe.db.get_value(
					"Item Price",
					{ item_code: code, price_list: pl, selling: 1 },
					"price_list_rate"
				);
			})
			.then(function (r) {
				if (r && r.message && flt(r.message.price_list_rate) > 0) {
					info.rate = flt(r.message.price_list_rate);
				}
				return info;
			})
			.catch(function () {
				return info;
			});
	}

	async function expand(parentCode) {
		var comp = cache[parentCode];
		if (!comp) return;
		expanded[parentCode] = true;
		window.__expBundleBusy = true;
		try {
			for (var i = 0; i < comp.length; i++) {
				var code = comp[i];
				// don't duplicate if the component is already on the bill
				var present = ((cur_pos.frm.doc.items || []).some(function (row) {
					return row.item_code === code;
				}));
				if (present) continue;
				var info = await getInfo(code);
				if (info.rate > 0) {
					await origUpdate({
						field: "qty",
						value: 1,
						item: { item_code: code, rate: info.rate, uom: info.uom, stock_uom: info.uom },
					});
				} else {
					frappe.show_alert({
						message: __("Set a price for {0} to auto-add it", [code]),
						indicator: "orange",
					});
				}
			}
		} finally {
			window.__expBundleBusy = false;
		}
	}

	function wrap() {
		if (!window.cur_pos || !cur_pos.on_cart_update) return;
		if (wrappedRef === cur_pos) return;
		origUpdate = cur_pos.on_cart_update.bind(cur_pos);
		cur_pos.on_cart_update = async function (args) {
			var res = await origUpdate(args);
			try {
				if (window.__expBundleBusy) return res;
				var it = args && args.item;
				var code = it && it.item_code;
				var field = args && args.field;
				if (code && field === "qty" && !expanded[code]) {
					// only expand if the tyre actually landed on the bill
					var inCart = (cur_pos.frm.doc.items || []).some(function (row) {
						return row.item_code === code;
					});
					if (inCart) {
						var comp = await getComponents(code);
						if (comp) await expand(code);
					}
				}
			} catch (e) {
				console.error("[express_tally] bundle expand failed", e);
			}
			return res;
		};
		wrappedRef = cur_pos;
		expanded = {};
	}

	// Reset the per-order "expanded" memory when the invoice changes or empties.
	function trackInvoice() {
		var frm = window.cur_pos && cur_pos.frm;
		if (!frm) return;
		var inv = frm.doc.name;
		var empty = !(frm.doc.items && frm.doc.items.length);
		if (inv !== lastInvoice || empty) {
			if (inv !== lastInvoice) expanded = {};
			if (empty) expanded = {};
			lastInvoice = inv;
		}
	}

	function wire() {
		wrap();
		window.expPOS.observe(".cart-items-section", function () {
			try { wrap(); trackInvoice(); } catch (e) {}
		});
		trackInvoice();
	}

	if (window.expPOS) {
		window.expPOS.onPOS(wire);
	} else {
		var w = 0;
		var t = setInterval(function () {
			if (window.expPOS) { clearInterval(t); window.expPOS.onPOS(wire); }
			else if (++w > 100) clearInterval(t);
		}, 100);
	}
})();
