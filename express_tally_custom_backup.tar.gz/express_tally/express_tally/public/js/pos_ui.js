// Express Tally - POS UI fixes (v4 - event-driven, no polling jank)
//  1) No blocking grey/white overlay while in the POS (frappe.dom.freeze sticks
//     if a step rejects, e.g. on customer select). Suppressed + auto-cleared.
//  2) Item loading call no longer passes freeze:true.
//  3) Item cards show the FULL item name (core truncates to 18 chars).
//  4) "New Invoice" works even while Recent Orders is open (core bails out then).
//
//  v4: the old 400ms setInterval that rewrote every card name 2.5x/sec (the grid
//  "jerk") is gone. Name-fixing now runs only when the grid actually re-renders,
//  via the shared rAF-debounced observer (expPOS). Prototype patches run once on
//  POS entry instead of being re-checked forever.
(function () {
	"use strict";
	if (window.__expPosUi_v4) return;
	window.__expPosUi_v4 = true;

	function inPOS() {
		try {
			return frappe.get_route && frappe.get_route()[0] === "point-of-sale";
		} catch (e) {
			return false;
		}
	}

	// ---------- 1) suppress the freeze overlay on the POS route (load-time) ----------
	if (window.frappe && frappe.dom && !frappe.dom.__expFreezeWrapped) {
		var origFreeze = frappe.dom.freeze;
		frappe.dom.freeze = function () {
			if (inPOS()) return;
			return origFreeze.apply(frappe.dom, arguments);
		};
		frappe.dom.__expFreezeWrapped = true;
	}
	function clearStuckFreeze() {
		if (!inPOS()) return;
		var els = document.querySelectorAll(".freeze");
		if (els.length) {
			try { frappe.dom.freeze_count = 0; } catch (e) {}
			Array.prototype.forEach.call(els, function (el) {
				if (el.parentNode) el.parentNode.removeChild(el);
			});
		}
	}

	// ---------- 2) non-blocking item load ----------
	function patchItemSelector() {
		if (!(window.erpnext && erpnext.PointOfSale && erpnext.PointOfSale.ItemSelector)) return false;
		var proto = erpnext.PointOfSale.ItemSelector.prototype;
		if (proto.__expUnfreeze) return true;
		proto.get_items = function (opts) {
			opts = opts || {};
			var start = opts.start || 0;
			var page_length = opts.page_length || 40;
			var search_term = opts.search_term || "";
			var doc = this.events.get_frm().doc;
			var price_list = (doc && doc.selling_price_list) || this.price_list;
			var item_group = this.item_group;
			var pos_profile = this.pos_profile;
			return frappe.call({
				method: "erpnext.selling.page.point_of_sale.point_of_sale.get_items",
				freeze: false,
				args: { start, page_length, price_list, item_group, search_term, pos_profile },
			});
		};
		proto.__expUnfreeze = true;
		return true;
	}

	// ---------- 4) New Invoice works from the Recent Orders screen ----------
	function patchNewInvoice() {
		if (!(window.erpnext && erpnext.PointOfSale && erpnext.PointOfSale.Controller)) return false;
		var proto = erpnext.PointOfSale.Controller.prototype;
		if (proto.__expNewInvoice) return true;
		var orig = proto.new_invoice_event;
		proto.new_invoice_event = function () {
			// Core returns early when the main panels are hidden (Recent Orders open).
			// In that case, go back to the POS and start a fresh invoice.
			if (this.$components_wrapper && !this.$components_wrapper.is(":visible")) {
				return this.load_new_invoice_on_pos();
			}
			return orig.apply(this, arguments);
		};
		proto.__expNewInvoice = true;
		return true;
	}

	// ---------- 3) full item names ----------
	function showFullNames() {
		var cards = document.querySelectorAll(".point-of-sale-app .item-wrapper");
		Array.prototype.forEach.call(cards, function (card) {
			var full = card.getAttribute("title");
			if (!full) return;
			var nameEl = card.querySelector(".item-name");
			if (nameEl && nameEl.textContent.trim() !== full) {
				nameEl.textContent = full;
			}
		});
	}

	// Apply the one-time prototype patches as soon as the POS classes exist.
	// (A short retry covers the brief window before erpnext.PointOfSale is ready.)
	function applyPatches() {
		var ok = patchItemSelector() && patchNewInvoice();
		if (!ok) {
			var tries = 0;
			var t = setInterval(function () {
				if ((patchItemSelector() && patchNewInvoice()) || ++tries > 40) clearInterval(t);
			}, 150);
		}
	}

	function wire() {
		applyPatches();
		// Grid re-renders + cart re-renders -> fix names + clear any stuck overlay,
		// coalesced to one pass per frame by expPOS (no per-clock reflow).
		window.expPOS.observe(".items-container", function () {
			showFullNames();
			clearStuckFreeze();
		});
		// First paint
		showFullNames();
		clearStuckFreeze();
	}

	if (window.expPOS) {
		window.expPOS.onPOS(wire);
	} else {
		// pos_observe.js loads first in hooks; this is just a safety net.
		var w = 0;
		var t = setInterval(function () {
			if (window.expPOS) { clearInterval(t); window.expPOS.onPOS(wire); }
			else if (++w > 100) clearInterval(t);
		}, 100);
	}
})();
