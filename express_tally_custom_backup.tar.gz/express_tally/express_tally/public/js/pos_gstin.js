// Express Tally - POS recipient GSTIN / B2B capture (v1)
//  A >5cr business must e-invoice every B2B sale (buyer has a GSTIN). The stock POS
//  always bills B2C ("Unregistered"), so registered buyers got no GSTIN on the bill
//  and no IRN. This adds a "GST No. (B2B)" box in the POS customer section:
//   - type a valid 15-char GSTIN  -> the bill becomes B2B:
//       gst_category      = "Registered Regular"
//       billing_address_gstin = <GSTIN>
//     india_compliance then derives place_of_supply from the GSTIN's state code and,
//     once e-invoicing is enabled, auto-generates the IRN + signed QR on submit.
//   - clear the box -> back to B2C ("Unregistered"), GSTIN removed.
//  Out-of-state buyers get IGST automatically: clearing place_of_supply makes
//  india_compliance re-derive it from the GSTIN state, and the server hook
//  express_tally.gst.enforce_gst_price_mode swaps the in-state template (CGST+SGST)
//  for the out-state one (IGST) whenever the place of supply isn't Gujarat.
(function () {
	"use strict";
	if (window.__expPosGstin_v1) return;
	window.__expPosGstin_v1 = true;

	var HOME_STATE = "24"; // Gujarat - Adarsh's GSTIN starts with 24
	var GSTIN_RE = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;

	var control = null;
	var $section = null;

	function getFrm() {
		return window.cur_pos && window.cur_pos.frm;
	}

	function inputFocused() {
		return control && control.$input && document.activeElement === control.$input.get(0);
	}

	function setB2B(gstin) {
		var frm = getFrm();
		if (!frm) return;
		gstin = (gstin || "").toUpperCase().trim();
		if (gstin) {
			frm.doc.gst_category = "Registered Regular";
			frm.doc.billing_address_gstin = gstin;
		} else {
			frm.doc.gst_category = "Unregistered";
			frm.doc.billing_address_gstin = "";
		}
		// force india_compliance to re-derive place_of_supply from the new GSTIN state
		frm.doc.place_of_supply = "";
		updateStatus(gstin);
	}

	function updateStatus(gstin) {
		if (!$section) return;
		var $st = $section.find(".exp-gstin-status");
		if (!gstin) {
			$st.html('<span class="text-muted">' + __("Walk-in / B2C (no GST input)") + "</span>");
			return;
		}
		if (!GSTIN_RE.test(gstin)) {
			$st.html('<span style="color:var(--red-500,#e24c4c);">' + __("Invalid GSTIN format") + "</span>");
			return;
		}
		var b2b = '<span style="color:var(--green-600,#28a745);">' + __("B2B - e-invoice will be generated") + "</span>";
		if (gstin.substr(0, 2) !== HOME_STATE) {
			b2b +=
				'<br><span style="color:var(--blue-500,#2490ef);">' +
				__("Out-of-state buyer - IGST will be applied automatically.") +
				"</span>";
		}
		$st.html(b2b);
	}

	function commit() {
		var gstin = control ? (control.get_value() || "").toUpperCase().trim() : "";
		if (gstin && !GSTIN_RE.test(gstin)) {
			updateStatus(gstin);
			return; // don't flip to B2B on a malformed GSTIN
		}
		setB2B(gstin);
	}

	function buildControl() {
		var $field = $section.find(".exp-gstin-control");
		control = frappe.ui.form.make_control({
			df: {
				fieldtype: "Data",
				label: __("GST No. (B2B)"),
				fieldname: "exp_gstin",
				placeholder: __("15-digit buyer GSTIN - leave blank for walk-in"),
				onchange: commit,
			},
			parent: $field.get(0),
			render_input: true,
		});
		control.refresh();
		var $inp = control.$input;
		if ($inp && $inp.length) {
			$inp.attr("maxlength", 15).css("text-transform", "uppercase");
			$inp.on("blur", commit);
			$inp.on("keydown", function (e) {
				e.stopPropagation();
				if (e.key === "Enter") $(this).blur();
			});
			$inp.on("input", function () {
				updateStatus(($inp.val() || "").toUpperCase().trim());
			});
		}
	}

	function inject() {
		if (!window.cur_pos) return;
		var $cs = $(".customer-cart-container .customer-section");
		if (!$cs.length) $cs = $(".customer-section");
		if (!$cs.length) return;

		if (!$section || !document.body.contains($section.get(0))) {
			$(".exp-gstin-section").remove();
			$section = $(
				'<div class="exp-gstin-section" style="padding:8px 14px;border-bottom:1px solid var(--border-color,#ebeff2);">' +
					'<div style="font-size:11px;color:var(--text-muted,#8d99a6);margin-bottom:4px;">' +
					__("GST No. (B2B)") +
					"</div>" +
					'<div class="exp-gstin-control"></div>' +
					'<div class="exp-gstin-status" style="font-size:11px;margin-top:4px;"></div>' +
					"</div>"
			);
			$cs.after($section);
			buildControl();
			updateStatus("");
		}

		// keep the box in sync if the invoice's GSTIN changed elsewhere (e.g. a B2B
		// customer with a stored GSTIN was picked) - but never while being typed in
		var frm = getFrm();
		if (control && frm && !inputFocused()) {
			var cur = (frm.doc.billing_address_gstin || "").toUpperCase();
			if ((control.get_value() || "").toUpperCase() !== cur) {
				control.set_value(cur);
				updateStatus(cur);
			}
		}
	}

	function wire() {
		window.expPOS.observe(".customer-cart-container", function () {
			try { inject(); } catch (e) {}
		});
		inject();
	}

	if (window.expPOS) {
		window.expPOS.onPOS(wire);
	} else {
		var w = 0;
		var t = setInterval(function () {
			if (window.expPOS) { clearInterval(t); window.expPOS.onPOS(wire); }
			else if (++w > 100) clearInterval(t);
		}, 100);
	}
})();
