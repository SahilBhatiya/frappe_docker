// Express Tally - POS WhatsApp mobile capture (v1)
//  Most customers have no phone number on file, so the cashier captures the
//  customer's mobile here at the counter. It is written to the bill's
//  custom_whatsapp_mobile field; on submit the auto-send WhatsApps the bill (PDF +
//  link) to that number, and the number is saved back to a named customer so future
//  payment reminders can reach them too.
//  Injected into the POS customer section, same pattern as the Car / GST No. fields.
(function () {
	"use strict";
	if (window.__expPosWaMobile_v1) return;
	window.__expPosWaMobile_v1 = true;

	var control = null;
	var $section = null;
	var lastCustomer = null;

	function getFrm() {
		return window.cur_pos && window.cur_pos.frm;
	}

	function inputFocused() {
		return control && control.$input && document.activeElement === control.$input.get(0);
	}

	function setMobile(val) {
		var frm = getFrm();
		if (!frm) return;
		frm.doc.custom_whatsapp_mobile = (val || "").trim();
	}

	function buildControl() {
		var $field = $section.find(".exp-wamobile-control");
		control = frappe.ui.form.make_control({
			df: {
				fieldtype: "Data",
				options: "Phone",
				label: __("Mobile (WhatsApp)"),
				fieldname: "exp_wa_mobile",
				placeholder: __("10-digit mobile to WhatsApp the bill"),
				onchange: function () {
					setMobile(control.get_value());
				},
			},
			parent: $field.get(0),
			render_input: true,
		});
		control.refresh();
		var $inp = control.$input;
		if ($inp && $inp.length) {
			$inp.attr("inputmode", "tel").attr("maxlength", 15);
			$inp.on("blur", function () { setMobile(control.get_value()); });
			$inp.on("keydown", function (e) {
				e.stopPropagation();
				if (e.key === "Enter") $(this).blur();
			});
		}
	}

	function prefillFromCustomer(customer) {
		// when a named customer with a saved number is picked, prefill it
		if (!customer || !control) return;
		frappe.db.get_value("Customer", customer, "mobile_no").then(function (r) {
			var mob = r && r.message ? r.message.mobile_no : "";
			var frm = getFrm();
			if (!frm) return;
			if (mob && !inputFocused()) {
				control.set_value(mob);
				frm.doc.custom_whatsapp_mobile = mob;
			} else if (!mob && !inputFocused() && !frm.doc.custom_whatsapp_mobile) {
				control.set_value("");
			}
		});
	}

	function inject() {
		if (!window.cur_pos) return;
		var $cs = $(".customer-cart-container .customer-section");
		if (!$cs.length) $cs = $(".customer-section");
		if (!$cs.length) return;

		if (!$section || !document.body.contains($section.get(0))) {
			$(".exp-wamobile-section").remove();
			$section = $(
				'<div class="exp-wamobile-section" style="padding:8px 14px;border-bottom:1px solid var(--border-color,#ebeff2);">' +
					'<div style="font-size:11px;color:var(--text-muted,#8d99a6);margin-bottom:4px;">' +
					__("Mobile (WhatsApp)") +
					"</div>" +
					'<div class="exp-wamobile-control"></div>' +
					"</div>"
			);
			$cs.after($section);
			buildControl();
			lastCustomer = null;
		}

		var frm = getFrm();
		var customer = frm && frm.doc.customer;
		if (customer !== lastCustomer) {
			lastCustomer = customer;
			prefillFromCustomer(customer);
		} else if (control && frm && !inputFocused()) {
			// keep in sync if the value changed elsewhere
			var cur = frm.doc.custom_whatsapp_mobile || "";
			if ((control.get_value() || "") !== cur) control.set_value(cur);
		}
	}

	function wire() {
		window.expPOS.observe(".customer-cart-container", function () {
			try { inject(); } catch (e) {}
		});
		inject();
	}

	if (window.expPOS) {
		window.expPOS.onPOS(wire);
	} else {
		var w = 0;
		var t = setInterval(function () {
			if (window.expPOS) { clearInterval(t); window.expPOS.onPOS(wire); }
			else if (++w > 100) clearInterval(t);
		}, 100);
	}
})();
