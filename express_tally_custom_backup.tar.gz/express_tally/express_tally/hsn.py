# Copyright (c) 2026, Adarsh Motor Stores and contributors
# HSN/SAC maintenance for GST compliance.
#
# The migration left every Item's gst_hsn_code as the placeholder "0000" (4-digit),
# but the migrated Sales Invoice lines carry the real >=6-digit codes that passed
# Tally's e-invoicing. For a >5cr business, B2B / e-invoice needs >=6-digit HSN, so
# backfill each Item master from the most-frequent >=6-digit code in its own history.

import frappe

BACKUP_TABLE = "_bak_item_hsn_20260611"


def _best_codes_from_history():
	"""item_code -> (hsn_code, freq) using only >=6-digit historical invoice codes."""
	rows = frappe.db.sql(
		"""select item_code, gst_hsn_code, count(*) c
		   from `tabSales Invoice Item`
		   where length(ifnull(gst_hsn_code,'')) >= 6
		   group by item_code, gst_hsn_code""",
		as_dict=True,
	)
	best = {}
	for r in rows:
		if r.item_code not in best or r.c > best[r.item_code][1]:
			best[r.item_code] = (r.gst_hsn_code, r.c)
	return best


def backfill_from_history(apply=False):
	"""Backfill Item.gst_hsn_code from invoice history. apply=False = dry-run report."""
	# one-time backup of the column
	exists = frappe.db.sql("show tables like %s", BACKUP_TABLE)
	if not exists:
		frappe.db.sql(
			f"create table `{BACKUP_TABLE}` as select name, gst_hsn_code from `tabItem`"
		)
		frappe.db.commit()

	best = _best_codes_from_history()
	active = [a.name for a in frappe.db.get_all("Item", filters={"disabled": 0}, fields=["name"])]
	resolvable = [a for a in active if a in best]
	manual = [a for a in active if a not in best]

	changed = 0
	if apply:
		for it in resolvable:
			new = best[it][0]
			cur = frappe.db.get_value("Item", it, "gst_hsn_code")
			if cur == new:
				continue
			if not frappe.db.exists("GST HSN Code", new):
				try:
					frappe.get_doc(
						{"doctype": "GST HSN Code", "hsn_code": new, "description": "Backfilled from sales history"}
					).insert(ignore_permissions=True)
				except Exception:
					frappe.clear_messages()
			frappe.db.set_value("Item", it, "gst_hsn_code", new, update_modified=False)
			changed += 1
		frappe.db.commit()

	print(
		f"ACTIVE={len(active)} RESOLVABLE={len(resolvable)} "
		f"MANUAL={len(manual)} CHANGED={changed}"
	)
	return {"active": len(active), "resolvable": len(resolvable), "manual": len(manual), "changed": changed}
