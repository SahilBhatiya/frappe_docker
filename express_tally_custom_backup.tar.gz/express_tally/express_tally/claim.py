# Copyright (c) 2026, Adarsh Motor Stores and contributors
# Tyre claim register report.
#
# Create / refresh the report with:
#   bench --site erpnext.localhost execute express_tally.claim.create_claim_report

import frappe

REPORT = "Tyre Claim Register"

_MFG_CASE = """CASE
		WHEN UPPER(sii.item_name) LIKE '%%MRF%%' THEN 'MRF'
		WHEN UPPER(sii.item_name) LIKE '%%CEAT%%' THEN 'CEAT'
		WHEN UPPER(sii.item_name) LIKE '%%APOLLO%%' THEN 'APOLLO'
		WHEN UPPER(sii.item_name) LIKE '%%VIKRANT%%' THEN 'VIKRANT'
		WHEN UPPER(sii.item_name) LIKE '%%BKT%%' THEN 'BKT'
		WHEN UPPER(sii.item_name) LIKE '%%JK%%' THEN 'JK'
		ELSE 'OTHER'
	END"""

QUERY = """
SELECT
	si.posting_date            AS "Date:Date:90",
	si.name                    AS "Invoice:Link/Sales Invoice:150",
	si.customer_name           AS "Customer::170",
	sii.item_code              AS "Tyre:Link/Item:230",
	sii.custom_claim_no        AS "Claim No.::110",
	sii.qty                    AS "Qty:Float:60",
	sii.price_list_rate        AS "Normal Rate:Currency:110",
	sii.rate                   AS "Claim Rate:Currency:110",
	(sii.price_list_rate - sii.rate) AS "Difference:Currency:110",
	sii.amount                 AS "Amount:Currency:110",
	{mfg}                      AS "Manufacturer::110"
FROM `tabSales Invoice Item` sii
JOIN `tabSales Invoice` si ON si.name = sii.parent
WHERE sii.custom_is_claim = 1
	AND si.docstatus = 1
	AND si.posting_date BETWEEN %(from_date)s AND %(to_date)s
	AND ( %(manufacturer)s = '' OR {mfg} = %(manufacturer)s )
ORDER BY si.posting_date DESC, si.name
""".format(mfg=_MFG_CASE)


def create_claim_report():
	if frappe.db.exists("Report", REPORT):
		doc = frappe.get_doc("Report", REPORT)
	else:
		doc = frappe.new_doc("Report")
		doc.report_name = REPORT

	doc.ref_doctype = "Sales Invoice"
	doc.report_type = "Query Report"
	doc.module = "Express Tally Integration"
	doc.is_standard = "No"
	doc.disabled = 0
	doc.query = QUERY

	doc.set("filters", [])
	doc.append("filters", {
		"fieldname": "from_date", "label": "From Date", "fieldtype": "Date",
		"mandatory": 1, "default": "2026-04-01",
	})
	doc.append("filters", {
		"fieldname": "to_date", "label": "To Date", "fieldtype": "Date",
		"mandatory": 1, "default": frappe.utils.today(),
	})
	doc.append("filters", {
		"fieldname": "manufacturer", "label": "Manufacturer", "fieldtype": "Select",
		"options": "\nMRF\nCEAT\nAPOLLO\nVIKRANT\nBKT\nJK\nOTHER", "default": "",
	})

	doc.set("roles", [])
	for r in ("System Manager", "Sales Manager", "Accounts Manager", "Sales User", "Accounts User"):
		doc.append("roles", {"role": r})

	doc.save(ignore_permissions=True)
	frappe.db.commit()
	print("Report ready:", REPORT)
	return REPORT
