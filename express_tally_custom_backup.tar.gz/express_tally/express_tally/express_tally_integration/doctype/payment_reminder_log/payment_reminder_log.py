# Copyright (c) 2026, Adarsh Motor Stores and contributors

import frappe
from frappe.model.document import Document


class PaymentReminderLog(Document):
	pass
