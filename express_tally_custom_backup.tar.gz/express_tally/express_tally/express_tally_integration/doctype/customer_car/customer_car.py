# Copyright (c) 2026, Adarsh Motor Stores and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document


class CustomerCar(Document):
	def before_insert(self):
		# Naming (autoname field:registration_number) happens before validate,
		# so normalize here too, otherwise the record name keeps the raw spacing/case.
		self.normalize_registration_number()

	def validate(self):
		self.normalize_registration_number()

	def normalize_registration_number(self):
		"""Uppercase and strip all spaces so 'GJ02 AB 1234' and 'GJ02AB1234'
		resolve to the same car (one master per registration number)."""
		if self.registration_number:
			normalized = "".join(self.registration_number.split()).upper()
			if normalized != self.registration_number:
				self.registration_number = normalized
