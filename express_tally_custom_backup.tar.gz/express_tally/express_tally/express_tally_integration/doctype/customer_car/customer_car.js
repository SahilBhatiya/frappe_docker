// Copyright (c) 2026, Adarsh Motor Stores and contributors
// For license information, please see license.txt

frappe.ui.form.on("Customer Car", {
	refresh(frm) {
		// Show which customers bring this car in (it can be more than one:
		// e.g. father and son both bring the same car).
		if (!frm.is_new()) {
			frm.add_custom_button(__("Customers with this Car"), () => {
				frappe
					.call({
						method: "express_tally.car.get_car_customers",
						args: { car: frm.doc.name },
					})
					.then((res) => {
						const names = [...new Set((res && res.message) || [])];
						if (!names.length) {
							frappe.msgprint(__("No customers linked to this car yet."));
							return;
						}
						const links = names
							.map(
								(n) =>
									`<li><a href="/app/customer/${encodeURIComponent(n)}">${frappe.utils.escape_html(n)}</a></li>`
							)
							.join("");
						frappe.msgprint({
							title: __("Customers with this Car"),
							message: `<ul>${links}</ul>`,
						});
					});
			});
		}
	},
});
