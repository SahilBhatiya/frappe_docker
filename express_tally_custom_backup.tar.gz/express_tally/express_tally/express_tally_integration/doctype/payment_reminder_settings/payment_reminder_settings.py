# Copyright (c) 2026, Adarsh Motor Stores and contributors

import frappe
from frappe.model.document import Document


class PaymentReminderSettings(Document):
	pass


@frappe.whitelist()
def send_test():
	"""Desk action: send one test message to test_mobile."""
	from express_tally.reminder import send_test_reminder

	return send_test_reminder()


@frappe.whitelist()
def preview():
	"""Desk action: list customers who would be reminded today (no send)."""
	from express_tally.reminder import preview_due_reminders

	return preview_due_reminders()


@frappe.whitelist()
def run_now():
	"""Desk action: run the reminder job immediately (respects enabled + gates)."""
	from express_tally.reminder import run_payment_reminders

	return run_payment_reminders(manual=True)
