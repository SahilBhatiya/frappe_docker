// Copyright (c) 2026, Adarsh Motor Stores and contributors
frappe.ui.form.on("Payment Reminder Settings", {
	refresh(frm) {
		frm.add_custom_button(__("Preview Due Today"), function () {
			frappe.call("express_tally.express_tally_integration.doctype.payment_reminder_settings.payment_reminder_settings.preview").then((r) => {
				const d = r.message || {};
				const rows = (d.rows || [])
					.map(
						(x) =>
							`<tr><td>${frappe.utils.escape_html(x.customer_name || x.customer)}</td>` +
							`<td style="text-align:right">${format_currency(x.outstanding, "INR")}</td>` +
							`<td style="text-align:center">${x.bills}</td>` +
							`<td>${x.reachable ? "✅ " + x.number : "❌ no number"}</td></tr>`
					)
					.join("");
				frappe.msgprint({
					title: __("{0} due, {1} reachable", [d.count, d.reachable]),
					message: `<div style="max-height:380px;overflow:auto"><table class="table table-bordered">
						<thead><tr><th>${__("Customer")}</th><th>${__("Outstanding")}</th><th>${__("Bills")}</th><th>${__("WhatsApp")}</th></tr></thead>
						<tbody>${rows}</tbody></table></div>`,
					wide: true,
				});
			});
		});

		frm.add_custom_button(__("Send Test Message"), function () {
			frappe.call("express_tally.express_tally_integration.doctype.payment_reminder_settings.payment_reminder_settings.send_test").then((r) => {
				const m = r.message || {};
				frappe.msgprint({
					title: m.ok ? __("Sent") : __("Not sent"),
					message: (m.number ? m.number + "<br>" : "") + frappe.utils.escape_html(m.message || ""),
					indicator: m.ok ? "green" : "red",
				});
			});
		});

		if (frm.doc.enabled) {
			frm.add_custom_button(__("Run Reminders Now"), function () {
				frappe.confirm(__("Send reminders now to everyone due today?"), function () {
					frappe.call("express_tally.express_tally_integration.doctype.payment_reminder_settings.payment_reminder_settings.run_now").then((r) => {
						const m = r.message || {};
						frappe.msgprint({
							title: __("Done"),
							message: `Sent: ${m.Sent || 0} · Failed: ${m.Failed || 0} · Skipped: ${m.Skipped || 0}`,
							indicator: "blue",
						});
					});
				});
			});
		}
	},
});
