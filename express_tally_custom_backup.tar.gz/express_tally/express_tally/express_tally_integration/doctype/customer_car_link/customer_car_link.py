# Copyright (c) 2026, Adarsh Motor Stores and contributors
# For license information, please see license.txt

from frappe.model.document import Document


class CustomerCarLink(Document):
	pass
