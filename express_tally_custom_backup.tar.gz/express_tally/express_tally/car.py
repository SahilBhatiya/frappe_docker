# Copyright (c) 2026, Adarsh Motor Stores and contributors
# Car <-> Customer linking helpers for the Express Tally app.

import frappe


@frappe.whitelist()
def get_customer_cars(customer):
	"""Return the list of car registration numbers linked to a customer."""
	if not customer:
		return []
	rows = frappe.get_all(
		"Customer Car Link",
		filters={"parenttype": "Customer", "parentfield": "custom_cars", "parent": customer},
		fields=["car", "make_model"],
		order_by="idx asc",
	)
	return rows


@frappe.whitelist()
def get_car_customers(car):
	"""Return the customers a given car is linked to (it can be more than one)."""
	if not car:
		return []
	rows = frappe.get_all(
		"Customer Car Link",
		filters={"parenttype": "Customer", "parentfield": "custom_cars", "car": car},
		fields=["parent"],
		distinct=True,
	)
	return [r.parent for r in rows]


@frappe.whitelist()
def set_car_odometer(car, odometer):
	"""Update a Customer Car's current odometer reading. Routed through a server
	method because Sales User has no write permission on Customer Car."""
	if not car:
		return
	frappe.db.set_value("Customer Car", car, "current_odometer", frappe.utils.flt(odometer))
	frappe.db.commit()
	return True


def link_car_to_customer(doc, method=None):
	"""On Sales Invoice submit: make sure the car recorded on the invoice is
	listed under the customer, so the same car shows up next time (and can be
	shared across customers - father/son both bring the same car)."""
	car = getattr(doc, "custom_car", None)
	customer = getattr(doc, "customer", None)
	if not car or not customer:
		return

	already = frappe.db.exists(
		"Customer Car Link",
		{"parenttype": "Customer", "parentfield": "custom_cars", "parent": customer, "car": car},
	)
	if already:
		return

	cust = frappe.get_doc("Customer", customer)
	cust.append("custom_cars", {"car": car})
	cust.save(ignore_permissions=True)
