# Copyright (c) 2026, Adarsh Motor Stores and contributors
# Tyre -> tube/flap bundle mapping for POS auto-add.
#
# Re-run after item/sales imports with:
#   bench --site erpnext.localhost execute express_tally.bundle.populate_bundle_mapping

import re
from collections import defaultdict, Counter

import frappe

BRANDS = ["MRF", "CEAT", "APOLLO", "JK", "VIKRANT", "BIRLA", "BKT", "RALSON", "METRO",
          "GTC", "DUNLOP", "BRIDGESTONE", "GOODYEAR", "MICHELIN", "CONTINENTAL", "PIRELLI",
          "YOKOHAMA", "TVS", "GOODRIDE", "WESTLAKE", "LINGLONG", "MAXXIS", "DURATURN",
          "NPR", "SUPERMILER", "ZAPPER", "SAVARI", "AUTOMILER"]


def _kind(name):
	u = name.upper()
	if "TUBE" in u:
		return "TUBE"
	if "FLAP" in u:
		return "FLAP"
	return "TYRE"


def _is_tubeless(name):
	u = " " + name.upper() + " "
	return bool(re.search(r"\bTL\b", u)) or "TUBELESS" in u


def _size_key(name):
	"""Whitespace-stripped size prefix (text before the first brand token).
	Tyre/tube of the same size yield the same key. '' if no digits (services)."""
	u = name.upper()
	idx = len(u)
	for b in BRANDS:
		p = u.find(" " + b)
		if p != -1:
			idx = min(idx, p)
	key = re.sub(r"\s+", "", u[:idx]).strip(" -/")
	return key if re.search(r"\d", key) else ""


def populate_bundle_mapping():
	items = frappe.get_all("Item", fields=["name", "item_name"])
	meta, tubes_by_size, flaps = {}, defaultdict(list), []
	for it in items:
		nm = it.item_name or it.name
		k, sk = _kind(nm), _size_key(nm)
		meta[it.name] = {"name": nm, "kind": k, "size": sk, "tubeless": _is_tubeless(nm)}
		if k == "TUBE" and sk:
			tubes_by_size[sk].append(it.name)
		elif k == "FLAP" and sk:
			flaps.append((it.name, sk))

	rows = frappe.db.sql(
		"select parent, item_code from `tabSales Invoice Item` where item_code is not null",
		as_dict=True,
	)
	inv, overall = defaultdict(list), Counter()
	for r in rows:
		inv[r.parent].append(r.item_code)
		overall[r.item_code] += 1

	tube_co, flap_co = defaultdict(Counter), defaultdict(Counter)
	for _parent, its in inv.items():
		its = list(dict.fromkeys(its))
		tys = [i for i in its if meta.get(i, {}).get("kind") == "TYRE"]
		tbs = [i for i in its if meta.get(i, {}).get("kind") == "TUBE"]
		fls = [i for i in its if meta.get(i, {}).get("kind") == "FLAP"]
		for t in tys:
			for x in tbs:
				tube_co[t][x] += 1
			for x in fls:
				flap_co[t][x] += 1

	def best_size_tube(sk):
		cand = tubes_by_size.get(sk, [])
		return max(cand, key=lambda c: overall.get(c, 0)) if cand else None

	def best_size_flap(sk):
		cand = [fn for (fn, fk) in flaps if sk and sk in fk]
		return max(cand, key=lambda c: overall.get(c, 0)) if cand else None

	frappe.db.sql("update `tabItem` set custom_bundle_tube=null, custom_bundle_flap=null")

	res = {"tube": 0, "flap": 0, "both": 0, "examples": []}
	for name, m in meta.items():
		if m["kind"] != "TYRE" or m["tubeless"] or not m["size"]:
			continue
		sk = m["size"]
		tube = tube_co[name].most_common(1)[0][0] if tube_co[name] else best_size_tube(sk)
		flap = flap_co[name].most_common(1)[0][0] if flap_co[name] else best_size_flap(sk)
		if not tube and not flap:
			continue
		frappe.db.set_value(
			"Item", name, {"custom_bundle_tube": tube, "custom_bundle_flap": flap},
			update_modified=False,
		)
		res["tube"] += 1 if tube else 0
		res["flap"] += 1 if flap else 0
		res["both"] += 1 if (tube and flap) else 0
		if len(res["examples"]) < 20:
			res["examples"].append({"tyre": m["name"], "tube": tube, "flap": flap})

	frappe.db.commit()
	print("BUNDLE MAPPING:", {k: v for k, v in res.items() if k != "examples"})
	for e in res["examples"]:
		print("  ", e["tyre"], "=>", "tube:", e["tube"] or "-", "| flap:", e["flap"] or "-")
	return res
