# Copyright (c) 2026, Adarsh Motor Stores and contributors
# One-time migration cleanup: reconcile the standalone (unallocated) customer
# Payment Entries imported from Tally against their outstanding invoices, so
# `outstanding_amount` reflects reality (bill references were lost in migration, so
# ERPNext's Payment Reconciliation tool allocates FIFO per customer - correct net
# per customer, which is what aging / reminders need). Uses the supported tool so
# all debits/credits net properly and GL stays balanced. Re-runnable; reversible via
# the standard Unreconcile.

import frappe
from frappe.utils import flt

COMPANY = "ADARSH MOTOR STORES"
RECEIVABLE = "Debtors - AMS"


def _customer_outstanding(customer):
	return flt(
		frappe.db.sql(
			"select sum(outstanding_amount) from `tabSales Invoice` "
			"where docstatus=1 and customer=%s and outstanding_amount>0",
			customer,
		)[0][0]
	)


def _customers_with_both():
	rows = frappe.db.sql(
		"""select a.customer from
		   (select customer from `tabSales Invoice`
		    where docstatus=1 and outstanding_amount>0 group by customer) a
		   join (select party from `tabPayment Entry`
		    where docstatus=1 and party_type='Customer' and unallocated_amount>0
		    group by party) b on a.customer=b.party""",
		as_dict=True,
	)
	return [r.customer for r in rows]


def _reconcile_one(customer):
	"""Returns (status, recovered_amount). status in ok/skipped/failed."""
	before = _customer_outstanding(customer)
	pr = frappe.new_doc("Payment Reconciliation")
	pr.company = COMPANY
	pr.party_type = "Customer"
	pr.party = customer
	pr.receivable_payable_account = RECEIVABLE
	pr.get_unreconciled_entries()
	if not pr.invoices or not pr.payments:
		return "skipped", 0.0
	invoices = [x.as_dict() for x in pr.invoices]
	payments = [x.as_dict() for x in pr.payments]
	pr.allocate_entries({"invoices": invoices, "payments": payments})
	if not pr.allocation:
		return "skipped", 0.0
	pr.reconcile()
	after = _customer_outstanding(customer)
	return "ok", before - after


def reconcile_all_customers(apply=False, limit=None):
	"""Dry-run by default: reports projected impact without committing. apply=True
	performs and commits per customer (atomic per customer)."""
	customers = _customers_with_both()
	if limit:
		customers = customers[: int(limit)]

	summary = {"total": len(customers), "ok": 0, "skipped": 0, "failed": 0, "recovered": 0.0}
	failures = []
	for cust in customers:
		try:
			if not apply:
				# project allocation only, never write
				before = _customer_outstanding(cust)
				pr = frappe.new_doc("Payment Reconciliation")
				pr.company = COMPANY
				pr.party_type = "Customer"
				pr.party = cust
				pr.receivable_payable_account = RECEIVABLE
				pr.get_unreconciled_entries()
				if not pr.invoices or not pr.payments:
					summary["skipped"] += 1
					continue
				pr.allocate_entries(
					{"invoices": [x.as_dict() for x in pr.invoices], "payments": [x.as_dict() for x in pr.payments]}
				)
				proj = sum(flt(a.allocated_amount) for a in pr.allocation if a.invoice_type == "Sales Invoice")
				summary["recovered"] += proj
				summary["ok"] += 1 if pr.allocation else 0
				if not pr.allocation:
					summary["skipped"] += 1
				frappe.db.rollback()
			else:
				status, recovered = _reconcile_one(cust)
				summary[status if status != "ok" else "ok"] += 1
				summary["recovered"] += flt(recovered)
				frappe.db.commit()
		except Exception:
			summary["failed"] += 1
			failures.append(cust)
			frappe.db.rollback()
			frappe.log_error(frappe.get_traceback(), "reconcile %s" % cust[:80])

	summary["recovered"] = round(summary["recovered"], 2)
	summary["failures"] = failures[:50]
	print("RECON_SUMMARY", summary)
	return summary
