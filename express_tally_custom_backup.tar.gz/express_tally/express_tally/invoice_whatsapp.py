# Copyright (c) 2026, Adarsh Motor Stores and contributors
#
# Auto-send the bill to the customer on WhatsApp when an invoice is submitted:
# a thank-you message + the invoice PDF (as a document) + a public link to view it
# online. Reuses the WhatsApp transport from express_tally.reminder (same BSP config
# on Payment Reminder Settings). The actual send is enqueued so the POS counter is
# never blocked.
#
# SAFETY: does nothing unless Payment Reminder Settings.send_invoice_on_submit is ON,
# and only messages a customer who has a resolvable WhatsApp number. Honours the
# per-customer opt-out (custom_disable_payment_reminders) and a dedupe flag so a bill
# is never sent twice.

import frappe
from frappe.utils import flt, fmt_money, get_url, now_datetime


# generic / control ledgers - never save a walk-in's number onto these
CONTROL_LEDGERS = {"Cash", "Net Banking Payment Sales", "XYZ", "Walk-in Customer", "Walk In Customer"}


def _settings():
	return frappe.get_cached_doc("Payment Reminder Settings")


def on_invoice_submit(doc, method=None):
	"""doc_event (Sales/POS Invoice on_submit): quick checks, then enqueue the send."""
	try:
		settings = _settings()
		if not settings.send_invoice_on_submit:
			return
		if doc.get("custom_whatsapp_bill_sent"):
			return
		if not doc.get("customer"):
			return
		if flt(doc.get("grand_total")) < flt(settings.min_invoice_amount):
			return
		if frappe.db.get_value("Customer", doc.customer, "custom_disable_payment_reminders"):
			return
		frappe.enqueue(
			"express_tally.invoice_whatsapp._send",
			queue="short",
			doctype=doc.doctype,
			invoice=doc.name,
			enqueue_after_commit=True,
		)
	except Exception:
		# never let a notification problem block the bill
		frappe.log_error(frappe.get_traceback(), "invoice_whatsapp on_submit")


def _public_pdf_url(doctype, invoice, print_format):
	"""Render the invoice to PDF, store as a PUBLIC File, return its absolute URL."""
	from express_tally.reminder import _settings as _s  # noqa: F401

	pdf = frappe.attach_print(doctype, invoice, print_format=print_format, doc=None)
	# frappe.attach_print returns {"fname":..., "fcontent": bytes}
	f = frappe.get_doc(
		{
			"doctype": "File",
			"file_name": pdf["fname"],
			"is_private": 0,
			"content": pdf["fcontent"],
			"attached_to_doctype": doctype,
			"attached_to_name": invoice,
		}
	)
	f.flags.ignore_permissions = True
	f.insert(ignore_permissions=True)
	return get_url(f.file_url)


def _log(customer, customer_name, mobile, amount, status, response):
	try:
		frappe.get_doc(
			{
				"doctype": "Payment Reminder Log",
				"kind": "Invoice",
				"customer": customer,
				"customer_name": customer_name,
				"mobile": mobile or "",
				"outstanding_amount": amount,
				"bills": 1,
				"status": status,
				"sent_on": now_datetime(),
				"response": (response or "")[:1000],
			}
		).insert(ignore_permissions=True)
	except Exception:
		frappe.log_error(frappe.get_traceback(), "invoice_whatsapp log")


def _send(doctype, invoice):
	"""Background worker: build PDF link + send the bill over WhatsApp."""
	from express_tally import reminder

	settings = _settings()
	if not settings.send_invoice_on_submit:
		return

	doc = frappe.get_doc(doctype, invoice)
	if doc.get("custom_whatsapp_bill_sent"):
		return

	# prefer the number captured on the bill at the counter; fall back to the
	# customer's saved number / linked contact
	cc = (settings.country_code or "91").strip()
	captured = reminder._normalise(doc.get("custom_whatsapp_mobile"), cc)
	number = captured or reminder.get_whatsapp_number(doc.customer, settings)
	if not number:
		_log(doc.customer, doc.get("customer_name"), None, flt(doc.grand_total), "Skipped", "No WhatsApp number")
		return

	# save a counter-captured number back to a NAMED customer so future reminders
	# reach them too (skip generic/control ledgers to avoid polluting them)
	if captured and doc.customer and doc.customer not in CONTROL_LEDGERS:
		try:
			if not frappe.db.get_value("Customer", doc.customer, "mobile_no"):
				frappe.db.set_value("Customer", doc.customer, "mobile_no", captured, update_modified=False)
		except Exception:
			pass

	try:
		bill_url = _public_pdf_url(doctype, invoice, settings.invoice_print_format or "Adarsh POS Invoice v2")
	except Exception:
		frappe.log_error(frappe.get_traceback(), "invoice_whatsapp pdf %s" % invoice[:80])
		_log(doc.customer, doc.get("customer_name"), number, flt(doc.grand_total), "Failed", "PDF generation failed")
		return

	ctx = {
		"customer": doc.get("customer_name") or doc.customer,
		"amount": fmt_money(flt(doc.grand_total), currency=doc.get("currency") or "INR"),
		"invoice_no": doc.name,
		"date": frappe.utils.formatdate(doc.get("posting_date")),
		"bill_url": bill_url,
		"count": 1,
	}
	ok, response = reminder.send_whatsapp(
		number,
		ctx,
		settings,
		template_name=settings.invoice_template_name,
		request_template=settings.invoice_request_template,
		endpoint=settings.get("invoice_api_endpoint"),
	)
	if ok:
		frappe.db.set_value(doctype, invoice, "custom_whatsapp_bill_sent", 1, update_modified=False)
		_log(doc.customer, doc.get("customer_name"), number, flt(doc.grand_total), "Sent", response)
	else:
		_log(doc.customer, doc.get("customer_name"), number, flt(doc.grand_total), "Failed", response)
	frappe.db.commit()


@frappe.whitelist()
def resend_invoice(doctype, invoice):
	"""Manual: (re)send a specific bill's WhatsApp now (ignores the dedupe flag)."""
	settings = _settings()
	if not settings.send_invoice_on_submit:
		return {"ok": False, "message": "Invoice WhatsApp is disabled."}
	frappe.db.set_value(doctype, invoice, "custom_whatsapp_bill_sent", 0, update_modified=False)
	_send(doctype, invoice)
	sent = frappe.db.get_value(doctype, invoice, "custom_whatsapp_bill_sent")
	return {"ok": bool(sent), "message": "Sent" if sent else "Not sent (see Payment Reminder Log)"}
